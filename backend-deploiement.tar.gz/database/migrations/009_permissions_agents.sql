-- Accès restreints par agent : la liste des domaines accordés par l'administratrice.
-- Additif : NULL = comportement historique (droits par défaut du rôle « staff »).
ALTER TABLE users
  ADD COLUMN permissions TEXT NULL DEFAULT NULL AFTER role;
