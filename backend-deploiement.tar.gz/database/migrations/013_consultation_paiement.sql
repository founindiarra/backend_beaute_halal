-- Parcours de réservation v3 : profil (ancienne / nouvelle), consultation capillaire et paiement de la consultation.
-- Colonnes toutes facultatives ou à valeur par défaut : les demandes existantes restent valables, rien n'est réécrit.
--   customer_kind        : 'ancienne' | 'nouvelle' (déclaré par la cliente ; le serveur recalcule le paiement, voir routes)
--   consultation_mode    : 'ignoree' | 'telephone' | 'whatsapp' | 'sur_place'
--   has_locks            : 1 / 0 (la cliente a-t-elle déjà des locks ?)
--   consultation_date/time : rendez-vous de consultation sur place
--   awaiting_payment     : 1 tant que la demande attend son paiement (elle n'est alors pas visible du salon)
--   payment_status       : 'none' | 'pending' | 'paid' | 'failed'
ALTER TABLE booking_requests
  ADD COLUMN customer_kind VARCHAR(10) NULL,
  ADD COLUMN consultation_mode VARCHAR(12) NULL,
  ADD COLUMN has_locks TINYINT(1) NULL,
  ADD COLUMN consultation_date DATE NULL,
  ADD COLUMN consultation_time TIME NULL,
  ADD COLUMN awaiting_payment TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN payment_status VARCHAR(10) NOT NULL DEFAULT 'none',
  ADD COLUMN payment_amount INT NULL,
  ADD COLUMN payment_method VARCHAR(12) NULL,
  ADD COLUMN payment_provider_id VARCHAR(80) NULL,
  ADD COLUMN paid_at DATETIME NULL,
  ADD INDEX idx_booking_requests_payment (awaiting_payment, payment_status);
