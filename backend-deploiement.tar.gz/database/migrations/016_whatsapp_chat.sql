-- Discussions WhatsApp du dashboard (onglet « Discussions » de la page WhatsApp).
-- Trois tables NOUVELLES ; rien d'existant n'est modifié, déplacé ni supprimé (ni clientes, ni journal des messages).
--   whatsapp_conversations : une ligne par correspondant WhatsApp (clientes enregistrées ou non) ;
--   whatsapp_messages      : tous les messages reçus et envoyés, avec leur état d'envoi ;
--   whatsapp_sync_state    : dernier événement du service WhatsApp déjà traité (reprise après un redémarrage).
-- Sûr à rejouer (IF NOT EXISTS / INSERT IGNORE).
-- Retour en arrière : DROP TABLE whatsapp_messages; DROP TABLE whatsapp_conversations; DROP TABLE whatsapp_sync_state;
--
-- Statuts d'un message (colonne status) : received (reçu) · sending (envoi en cours) · sent (accepté par WhatsApp)
--   delivered (remis) · read (lu) · failed (échec : « Réessayer » possible sans doublon).
-- Origines (colonne origin) : client · dashboard (écrit depuis le dashboard) · phone (écrit depuis le téléphone du salon)
--   · auto (notification automatique du site).

CREATE TABLE IF NOT EXISTS whatsapp_conversations (
  id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  jid                   VARCHAR(80)  NOT NULL,
  phone                 VARCHAR(20)  NULL,
  phone_key             VARCHAR(20)  NULL,
  push_name             VARCHAR(80)  NULL,
  customer_id           INT UNSIGNED NULL,
  last_message_at       DATETIME(3)  NULL,
  last_message_preview  VARCHAR(200) NULL,
  last_direction        VARCHAR(3)   NULL,
  unread_count          INT UNSIGNED NOT NULL DEFAULT 0,
  created_at            DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at            DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_wa_conv_jid (jid),
  KEY idx_wa_conv_last (last_message_at),
  KEY idx_wa_conv_phone_key (phone_key),
  KEY idx_wa_conv_customer (customer_id),
  KEY idx_wa_conv_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS whatsapp_messages (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  conversation_id  INT UNSIGNED NOT NULL,
  wa_message_id    VARCHAR(120) NULL,
  client_ref       VARCHAR(64)  NULL,
  direction        VARCHAR(3)   NOT NULL,
  origin           VARCHAR(10)  NOT NULL DEFAULT 'client',
  body             TEXT         NOT NULL,
  media_type       VARCHAR(12)  NULL,
  status           VARCHAR(10)  NOT NULL DEFAULT 'received',
  error_code       VARCHAR(40)  NULL,
  sent_by          INT UNSIGNED NULL,
  wa_timestamp     DATETIME(3)  NOT NULL,
  created_at       DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at       DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_wa_msg_wa_id (wa_message_id),
  UNIQUE KEY uq_wa_msg_client_ref (client_ref),
  KEY idx_wa_msg_conv_time (conversation_id, wa_timestamp, id),
  KEY idx_wa_msg_updated (updated_at),
  CONSTRAINT fk_wa_msg_conv FOREIGN KEY (conversation_id) REFERENCES whatsapp_conversations (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS whatsapp_sync_state (
  id          TINYINT UNSIGNED NOT NULL,
  last_seq    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  updated_at  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO whatsapp_sync_state (id, last_seq) VALUES (1, 0);
