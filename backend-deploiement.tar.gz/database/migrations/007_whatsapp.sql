-- WhatsApp Business Cloud API : nouveau canal de messagerie.
-- Additif : les lignes existantes ne changent pas.
ALTER TABLE message_logs
  MODIFY COLUMN channel ENUM('sms','email','whatsapp') NOT NULL;

ALTER TABLE customers
  ADD COLUMN whatsapp_opt_in TINYINT(1) NOT NULL DEFAULT 1 AFTER email_opt_in;
