-- ─────────────────────────────────────────────────────────────────────────────
-- Nouvelle logique : trois catégories (les types de locks) et des prestations
-- qui sont les COIFFURES du salon, sans prix ni durée à saisir.
--
--  1. Les trois catégories : Locks Traditionnels, Small Locks, Micro-Locks.
--  2. Chaque prestation existante est rangée dans l'une des trois (selon son
--     nom, sa description ou son ancienne catégorie ; à défaut : traditionnels).
--  3. Les anciennes catégories sont supprimées — sauf celle qui porte la
--     prestation technique des demandes du site (inactive, invisible du public).
--  4. Les photos de la galerie « Nos coiffures » deviennent des prestations
--     (une par photo), pour que la page du site reste alimentée. Les lignes de
--     la galerie ne sont pas supprimées.
--
-- Les colonnes `price` et `duration_minutes` restent en base : les rendez-vous
-- et les anciens sites en ont encore besoin ; elles ne sont plus saisies.
-- ─────────────────────────────────────────────────────────────────────────────

INSERT INTO service_categories (slug, name, description, position, is_active) VALUES
  ('traditionnels', 'Locks Traditionnels', 'Locks classiques aux dimensions généreuses.', 1, 1),
  ('small', 'Small Locks', 'Locks fines et élégantes, pour un rendu raffiné.', 2, 1),
  ('micro', 'Micro-Locks', 'Le summum du détail et de la finesse.', 3, 1)
ON DUPLICATE KEY UPDATE position = VALUES(position), is_active = 1;

-- 2. Ranger les prestations existantes (hors prestation technique).
UPDATE services s
  JOIN service_categories c ON c.id = s.category_id
   SET s.category_id = (
     SELECT t.id FROM service_categories t WHERE t.slug = CASE
       WHEN CONCAT_WS(' ', s.name, s.description, c.name) LIKE '%micro%' THEN 'micro'
       WHEN CONCAT_WS(' ', s.name, s.description, c.name) LIKE '%small%' THEN 'small'
       ELSE 'traditionnels' END)
 WHERE c.slug NOT IN ('traditionnels', 'small', 'micro')
   AND s.slug <> 'prestation-sur-mesure-site';

-- 3. Supprimer les anciennes catégories devenues vides.
DELETE FROM service_categories
 WHERE slug NOT IN ('traditionnels', 'small', 'micro')
   AND id NOT IN (SELECT category_id FROM services);

-- 4. Les photos de la galerie deviennent des prestations (idempotent : slug unique).
INSERT IGNORE INTO services
  (category_id, slug, name, description, duration_minutes, price, currency, image_url,
   is_featured, is_active, position)
SELECT
  (SELECT t.id FROM service_categories t WHERE t.slug = CASE
     WHEN CONCAT_WS(' ', g.title, g.description, gc.name) LIKE '%micro%' THEN 'micro'
     WHEN CONCAT_WS(' ', g.title, g.description, gc.name) LIKE '%small%' THEN 'small'
     ELSE 'traditionnels' END),
  CONCAT('coiffure-', g.id), LEFT(g.title, 140), g.description, 60, 0, 'FCFA', g.image_url,
  g.is_featured, g.is_active, g.position
FROM gallery_items g
JOIN gallery_categories gc ON gc.id = g.category_id;
