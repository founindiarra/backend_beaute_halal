-- Une demande du site v3 confirmée devient un rendez-vous suivi (arrivée, paiement, reçu…).
-- Additif : on garde le lien demande → rendez-vous, rien d'existant ne change.
ALTER TABLE booking_requests
  ADD COLUMN appointment_id INT UNSIGNED NULL DEFAULT NULL AFTER customer_id,
  ADD KEY idx_booking_requests_appointment (appointment_id);
