-- Créneau souhaité : la cliente choisit un jour ET une heure parmi les créneaux libres du salon.
-- Colonne facultative (NULL = ancienne demande, ou cliente sans préférence d'heure) : rien n'est réécrit.
-- Le créneau reste un SOUHAIT : le rendez-vous reste « en attente » jusqu'à la confirmation du salon.
ALTER TABLE booking_requests
  ADD COLUMN desired_time TIME NULL AFTER desired_date;
