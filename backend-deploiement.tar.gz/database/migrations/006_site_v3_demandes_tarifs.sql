-- ─────────────────────────────────────────────────────────────────────────────
-- Site v3 : demandes de rendez-vous SANS créneau + catalogue tarifaire.
--
-- Tout est ajouté, rien n'est modifié : aucune table existante n'est touchée,
-- les sites 1 et 2 et le dashboard continuent de fonctionner à l'identique.
--
-- 1. booking_requests — la demande telle que le site v3 la formule : un besoin
--    (création complète / resserrage), le type de locks, le volume, la formule,
--    le délai, l'état, un jour souhaité (jamais d'heure), et la coiffure vue
--    dans « Nos coiffures ». Le salon appelle ensuite la cliente pour fixer
--    le jour et l'heure. Le montant est calculé PAR LE SERVEUR, jamais lu
--    depuis le navigateur.
--
-- 2. pricing_catalogue — la grille tarifaire (types, volumes, prix, délais,
--    états, réparation, consultation). Une seule ligne JSON, modifiable par
--    l'administratrice ; si elle est vide, le serveur la remplit avec la
--    grille des documents du salon.
--
-- Retour en arrière : DROP TABLE booking_requests; DROP TABLE pricing_catalogue;
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS booking_requests (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reference        VARCHAR(20)  NOT NULL,
  status           ENUM('pending','contacted','confirmed','rejected','cancelled','completed')
                   NOT NULL DEFAULT 'pending',

  besoin           ENUM('creation','resserrage') NOT NULL,
  lock_type        VARCHAR(40)  NULL,
  volume           VARCHAR(8)   NULL,
  longueur         VARCHAR(20)  NULL,
  formule          VARCHAR(20)  NULL,
  delai            VARCHAR(30)  NULL,
  etat             VARCHAR(30)  NULL,
  estimate_total   INT UNSIGNED NULL,
  estimate_partial TINYINT(1)   NOT NULL DEFAULT 0,

  desired_date     DATE         NULL,
  inspiration_id   INT UNSIGNED NULL,
  inspiration_title VARCHAR(200) NULL,

  customer_id      INT UNSIGNED NULL,
  first_name       VARCHAR(80)  NOT NULL,
  last_name        VARCHAR(80)  NOT NULL,
  phone            VARCHAR(40)  NOT NULL,
  email            VARCHAR(160) NOT NULL,
  birth_date       DATE         NULL,
  note             TEXT         NULL,
  message          TEXT         NOT NULL,

  admin_note       TEXT         NULL,
  handled_at       DATETIME     NULL,
  source           VARCHAR(20)  NOT NULL DEFAULT 'site-v3',
  ip_address       VARCHAR(45)  NULL,
  created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_booking_requests_reference (reference),
  KEY idx_booking_requests_status (status, created_at),
  KEY idx_booking_requests_desired (desired_date),
  KEY idx_booking_requests_customer (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pricing_catalogue (
  id         TINYINT UNSIGNED NOT NULL,
  data       LONGTEXT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
