-- Heures proposées selon le profil de la cliente (ancienne : 09:00 ; nouvelle : 10:00 ; autres cas : 14:00 / 14:30).
-- Additif : ajoute seulement les créneaux manquants, ne modifie ni ne supprime ceux qui existent.
INSERT IGNORE INTO time_slots (start_time, position, is_active) VALUES
  ('09:00:00', 0, 1),
  ('10:00:00', 1, 1),
  ('14:00:00', 3, 1),
  ('14:30:00', 3, 1);
