-- ─────────────────────────────────────────────────────────────────────────────
-- La demande du site devient un rendez-vous dès sa création.
--
-- Le dashboard n'a plus de page « Demandes du site » : une demande arrive dans
-- « Rendez-vous » comme un rendez-vous en attente (jour souhaité, heure à fixer),
-- le salon la marque « Contactée », puis la confirme en fixant jour, heure et prix.
--
--  1. Nouveau statut de rendez-vous : « contacted » (ajouté en fin de liste :
--     aucune ligne existante n'est réécrite).
--  2. Rattrapage : chaque demande encore ouverte (en attente ou contactée) qui
--     n'a pas de rendez-vous en reçoit un, avec la même référence. L'heure est
--     un repère technique entre 00:00 et 05:33 (hors horaires d'ouverture), unique
--     par demande pour respecter l'unicité d'un créneau ; elle est remplacée par
--     l'heure convenue à la confirmation.
-- ─────────────────────────────────────────────────────────────────────────────

ALTER TABLE appointments
  MODIFY status ENUM(
      'pending','confirmed','rejected','cancelled',
      'arrived','in_progress','completed','no_show','contacted'
    ) NOT NULL DEFAULT 'pending';

-- Prestation technique (inactive, invisible du public) qui porte ces rendez-vous.
INSERT IGNORE INTO service_categories (slug, name, description, position, is_active)
VALUES ('sur-mesure-site', 'Sur mesure (demandes du site)',
        'Catégorie technique : rendez-vous issus des demandes du site.', 999, 0);

INSERT IGNORE INTO services
  (category_id, slug, name, description, duration_minutes, price, is_active, position)
SELECT c.id, 'prestation-sur-mesure-site', 'Prestation sur mesure (demande du site)',
       'Technique : porte les rendez-vous créés depuis une demande du site.', 180, 0, 0, 999
FROM service_categories c WHERE c.slug = 'sur-mesure-site';

-- Rattrapage des demandes ouvertes.
INSERT IGNORE INTO appointments
  (reference, service_id, service_name, appointment_date, appointment_time, duration_minutes,
   price, currency, first_name, last_name, phone, email, note, status, source, customer_id)
SELECT
  r.reference,
  (SELECT s.id FROM services s WHERE s.slug = 'prestation-sur-mesure-site'),
  LEFT(CASE WHEN r.besoin = 'creation'
         THEN CONCAT('Création complète — ', CASE r.lock_type WHEN 'traditionnels' THEN 'Locks Traditionnels' WHEN 'small' THEN 'Small Locks' WHEN 'micro' THEN 'Micro-Locks' ELSE 'locks' END)
         ELSE CONCAT('Resserrage — ', CASE r.lock_type WHEN 'traditionnels' THEN 'Locks Traditionnels' WHEN 'small' THEN 'Small Locks' WHEN 'micro' THEN 'Micro-Locks' ELSE 'locks' END,
                     IF(r.volume IS NULL, '', CONCAT(' · volume ', r.volume))) END, 140),
  r.desired_date,
  SEC_TO_TIME(MOD(r.id, 20000)),
  15,
  COALESCE(r.estimate_total, 0),
  'FCFA',
  r.first_name, r.last_name, r.phone, r.email, r.note,
  IF(r.status = 'contacted', 'contacted', 'pending'),
  'site-v3',
  r.customer_id
FROM booking_requests r
WHERE r.appointment_id IS NULL AND r.status IN ('pending', 'contacted');

UPDATE booking_requests r
  JOIN appointments a ON a.reference = r.reference AND a.source = 'site-v3'
   SET r.appointment_id = a.id
 WHERE r.appointment_id IS NULL AND r.status IN ('pending', 'contacted');
