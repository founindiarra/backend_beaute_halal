-- Suivi des paiements Jèko (rubrique « Paiements Jèko » du dashboard).
-- Deux tables NOUVELLES, rien d'existant n'est modifié ni réécrit :
--   payment_attempts : une ligne par tentative de paiement (une demande peut en avoir plusieurs) ;
--   payment_events   : le journal technique — création chez Jèko, webhooks reçus, vérifications de statut.
-- Aucun secret n'y est jamais écrit (ni clé, ni signature, ni secret de webhook) ; les numéros de téléphone
-- reçus de Jèko sont masqués avant enregistrement.
--
-- Statuts d'une tentative (colonne status) :
--   pending   en attente (créée chez Jèko, pas encore confirmée)
--   success   payée — uniquement sur confirmation fiable (webhook signé ou statut lu chez Jèko)
--   failed    échouée (refus à la création, ou « error » rapporté par Jèko)
--   cancelled annulée
--   expired   expirée
-- Retour en arrière : DROP TABLE payment_events; DROP TABLE payment_attempts;

CREATE TABLE IF NOT EXISTS payment_attempts (
  id                      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_request_id      INT UNSIGNED NULL,
  request_reference       VARCHAR(30) NOT NULL,
  customer_name           VARCHAR(160) NULL,
  customer_phone          VARCHAR(30) NULL,
  method                  VARCHAR(12) NULL,
  amount                  INT NULL,
  currency                CHAR(3) NOT NULL DEFAULT 'XOF',
  status                  VARCHAR(12) NOT NULL DEFAULT 'pending',
  mode                    VARCHAR(8) NOT NULL DEFAULT 'live',
  jeko_reference          VARCHAR(80) NULL,
  jeko_payment_request_id VARCHAR(80) NULL,
  jeko_transaction_id     VARCHAR(80) NULL,
  jeko_status             VARCHAR(30) NULL,
  error_reason            VARCHAR(255) NULL,
  error_http_status       SMALLINT NULL,
  error_message           VARCHAR(500) NULL,
  redirect_host           VARCHAR(120) NULL,
  amount_warning          TINYINT(1) NOT NULL DEFAULT 0,
  created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  completed_at            DATETIME NULL,
  last_checked_at         DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_payment_attempts_status (status, created_at),
  KEY idx_payment_attempts_created (created_at),
  KEY idx_payment_attempts_request (request_reference),
  KEY idx_payment_attempts_booking (booking_request_id),
  KEY idx_payment_attempts_pr (jeko_payment_request_id),
  KEY idx_payment_attempts_ref (jeko_reference),
  KEY idx_payment_attempts_txn (jeko_transaction_id),
  CONSTRAINT fk_payment_attempts_booking FOREIGN KEY (booking_request_id)
    REFERENCES booking_requests (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_events (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  attempt_id         INT UNSIGNED NULL,
  request_reference  VARCHAR(30) NULL,
  source             VARCHAR(12) NOT NULL,   -- initiation | webhook | verification
  event_type         VARCHAR(40) NULL,       -- ex. TRANSACTION_COMPLETED (en-tête Jeko-Event)
  http_status        SMALLINT NULL,          -- webhook : code que nous avons répondu ; autre : code renvoyé par Jèko
  signature_valid    TINYINT(1) NULL,        -- webhook seulement
  outcome            VARCHAR(16) NOT NULL,   -- processed | duplicate | ignored | unmatched | rejected | error
  reported_status    VARCHAR(30) NULL,       -- statut annoncé par Jèko
  jeko_id            VARCHAR(80) NULL,
  message            VARCHAR(500) NULL,
  duration_ms        INT NULL,
  payload            TEXT NULL,              -- corps reçu, tronqué et sans donnée sensible
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_payment_events_attempt (attempt_id, created_at),
  KEY idx_payment_events_created (created_at),
  KEY idx_payment_events_outcome (outcome, created_at),
  KEY idx_payment_events_source (source, created_at),
  CONSTRAINT fk_payment_events_attempt FOREIGN KEY (attempt_id)
    REFERENCES payment_attempts (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reprise de l'historique : les paiements déjà tentés avant cette migration apparaissent dans la rubrique.
-- Lecture seule sur booking_requests ; le statut est celui déjà connu (paid → success).
INSERT INTO payment_attempts
  (booking_request_id, request_reference, customer_name, customer_phone, method, amount, status, mode,
   jeko_payment_request_id, jeko_status, created_at, completed_at)
SELECT b.id, b.reference, TRIM(CONCAT_WS(' ', b.first_name, b.last_name)), b.phone, b.payment_method, b.payment_amount,
       CASE b.payment_status WHEN 'paid' THEN 'success' WHEN 'failed' THEN 'failed' ELSE 'pending' END,
       CASE WHEN b.payment_provider_id LIKE 'mock-%' THEN 'mock' ELSE 'live' END,
       b.payment_provider_id, NULL, b.created_at, b.paid_at
FROM booking_requests b
WHERE b.payment_provider_id IS NOT NULL AND b.payment_provider_id <> ''
  AND NOT EXISTS (SELECT 1 FROM payment_attempts a WHERE a.booking_request_id = b.id);
