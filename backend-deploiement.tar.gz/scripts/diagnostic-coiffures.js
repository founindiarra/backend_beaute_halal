/**
 * Diagnostic des coiffures (page « Prestations » ↔ page « Nos coiffures » du site).
 *
 *   node scripts/diagnostic-coiffures.js                    → LECTURE SEULE : liste les coiffures avec photo,
 *                                                             repère les photos présentes plusieurs fois
 *   node scripts/diagnostic-coiffures.js --masquer-doublons → pour chaque photo en double, garde visible la ligne
 *                                                             modifiée en dernier (celle que vous avez renommée)
 *                                                             et MASQUE les autres (is_active = 0, réversible depuis
 *                                                             le dashboard). Rien n'est supprimé.
 *
 * Le site affiche le nom de chaque prestation visible : si une même photo existe deux fois, le site peut montrer
 * la ligne qui a gardé l'ancien nom. Écrit dans la base du `.env` du dossier courant : vérifiez le nom affiché.
 */
import { basename } from 'node:path'

import { config } from '../src/config/env.js'
import { closePool, execute, query } from '../src/config/database.js'

const masquer = process.argv.includes('--masquer-doublons')
console.log(`Base visée : ${config.db.database} (${config.env})`)
console.log(masquer ? 'MODE ÉCRITURE (--masquer-doublons)' : 'MODE LECTURE SEULE')

const cle = (url) =>
  basename(String(url).split('?')[0])
    .replace(/\.[a-z0-9]+$/i, '')
    .replace(/^salon-/, '')
    // L'ancien script d'import préfixait la photo d'un code (ex. « mvfaom03- ») : on l'ignore pour comparer.
    .replace(/^(?=[a-z0-9]{6,9}-)[a-z0-9]*\d[a-z0-9]*-/, '')

try {
  const rows = await query(
    `SELECT id, slug, name, is_active, image_url, updated_at FROM services
      WHERE image_url IS NOT NULL AND image_url <> '' ORDER BY id`,
  )
  console.log(`\n${rows.length} coiffure(s) avec photo (${rows.filter((r) => r.is_active).length} visible(s) sur le site)\n`)
  for (const r of rows) {
    console.log(`#${r.id}  ${r.is_active ? 'VISIBLE' : 'masquée'}  « ${r.name} »  [${r.slug}]  photo: ${cle(r.image_url)}`)
  }

  const groupes = new Map()
  for (const r of rows) groupes.set(cle(r.image_url), [...(groupes.get(cle(r.image_url)) ?? []), r])
  const doubles = [...groupes.entries()].filter(([, l]) => l.filter((r) => r.is_active).length > 1)

  if (!doubles.length) {
    console.log('\nAucune photo en double parmi les coiffures visibles.')
  } else {
    console.log(`\n${doubles.length} photo(s) visible(s) en double :`)
    let masquees = 0
    for (const [photo, liste] of doubles) {
      const visibles = liste.filter((r) => r.is_active)
      const garde = [...visibles].sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at) || b.id - a.id)[0]
      console.log(`\n  Photo « ${photo} »`)
      for (const r of visibles) {
        console.log(`    #${r.id} « ${r.name} » (modifiée ${new Date(r.updated_at).toISOString().slice(0, 16)})${r.id === garde.id ? '  ← gardée' : '  ← à masquer'}`)
        if (masquer && r.id !== garde.id) {
          await execute('UPDATE services SET is_active = 0 WHERE id = ?', [r.id])
          masquees += 1
        }
      }
    }
    console.log(masquer ? `\n${masquees} ligne(s) masquée(s). Réversible depuis la page Prestations.` : '\nRien n’a été modifié. Ajoutez --masquer-doublons pour masquer les lignes « à masquer ».')
  }
} finally {
  await closePool()
}
