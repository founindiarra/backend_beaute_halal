/**
 * Importe dans le dashboard (table `services`, page « Prestations ») les 28 coiffures du salon
 * qui étaient intégrées au site, avec leurs photos et leurs titres à jour.
 *
 *   node scripts/import-coiffures/importer.js            → SIMULATION : n'écrit rien, liste ce qui serait fait
 *   node scripts/import-coiffures/importer.js --apply    → crée les coiffures et copie les photos
 *
 * Sûr à relancer : une coiffure déjà importée (même identifiant « coiffure-salon-… ») est ignorée.
 * Ne supprime et ne modifie jamais rien d'existant. Écrit dans la base du `.env` du dossier où vous le lancez :
 * vérifiez le nom de base affiché avant d'ajouter --apply.
 */
import { copyFileSync, existsSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { config } from '../../src/config/env.js'
import { closePool, query } from '../../src/config/database.js'

const ici = dirname(fileURLToPath(import.meta.url))
const appliquer = process.argv.includes('--apply')
const liste = JSON.parse(readFileSync(join(ici, 'coiffures-salon.json'), 'utf8'))

console.log(`Base visée : ${config.db.database} (${config.env})`)
console.log(appliquer ? 'MODE ÉCRITURE (--apply)' : 'MODE SIMULATION (aucune écriture)')

const categories = new Map((await query('SELECT id, slug FROM service_categories')).map((c) => [c.slug, c.id]))
const manquantes = ['traditionnels', 'small', 'micro'].filter((s) => !categories.has(s))
if (manquantes.length) {
  console.error(`Arrêt : catégories absentes (${manquantes.join(', ')}). Appliquez d'abord les migrations (npm run db:migrate).`)
  await closePool()
  process.exit(1)
}

let crees = 0
let ignorees = 0
for (const c of liste) {
  const slug = `coiffure-salon-${c.slug}`
  const source = join(ici, 'images', `${c.slug}.webp`)
  if (!existsSync(source)) {
    console.log(`  ! photo introuvable : ${c.slug}.webp — ignorée`)
    ignorees += 1
    continue
  }
  const [existe] = await query('SELECT id FROM services WHERE slug = ? LIMIT 1', [slug])
  if (existe) {
    console.log(`  = déjà là : ${c.title}`)
    ignorees += 1
    continue
  }
  console.log(`  + ${appliquer ? 'création' : 'à créer'} : ${c.title} (${c.type})`)
  if (appliquer) {
    const fichier = `salon-${c.slug}.webp`
    copyFileSync(source, join(config.upload.dir, fichier))
    await query(
      `INSERT INTO services (category_id, slug, name, description, duration_minutes, price, currency, image_url, is_featured, is_active, position)
       VALUES (?, ?, ?, ?, 60, 0, 'FCFA', ?, ?, 1, ?)`,
      [categories.get(c.type), slug, c.title.slice(0, 140), c.description, `${config.upload.publicPath}/${fichier}`, c.featured ? 1 : 0, c.position],
    )
  }
  crees += 1
}
console.log(`\n${appliquer ? 'Créées' : 'À créer'} : ${crees} · ignorées : ${ignorees}`)
if (!appliquer) console.log('Rien n’a été écrit. Ajoutez --apply pour importer.')
await closePool()
