import { Router } from 'express'
import { z } from 'zod'

import { config } from '../../config/env.js'
import { ApiError } from '../../lib/ApiError.js'
import { sendData } from '../../lib/http.js'
import { journaliserPaiement } from '../../lib/journalPaiement.js'
import { METHODES, creerPaiement, jekoPret, jekoSimule } from '../../lib/jeko.js'
import { bookingLimiter } from '../../middleware/rateLimit.js'
import { validate } from '../../middleware/validate.js'
import { findByReference, serializePublic, setPaymentAttempt } from '../booking-requests/model.js'
import { creerTentative, enregistrerEvenement, majTentative, tentativesEnAttente } from './journal.js'
import { confirmerPaiement, verifierTentative } from './service.js'
import { webhookRouter } from './webhook.js'

/**
 * Paiement de la consultation (nouvelles clientes), via Jèko.
 *
 *  1. La demande est enregistrée « en attente de paiement » (invisible du salon).
 *  2. POST /payments/initiate : on crée la demande de paiement chez Jèko et on renvoie `redirectUrl`.
 *  3. La cliente paie sur Jèko ; Jèko prévient POST /payments/jeko/webhook (signé).
 *  4. Le webhook confirme : la demande est finalisée (fiche, rendez-vous, messages, SMS/e-mail/WhatsApp).
 *
 * Le retour de la cliente sur le site ne vaut jamais confirmation : seul le webhook (ou la simulation) paie.
 */
export const publicRouter = Router()

const referenceSchema = z.string().regex(/^[A-Za-z]{2}-[A-Za-z0-9]{4,10}$/, 'Référence invalide.')

const siteBase = () => (config.siteUrl || config.corsOrigins[0] || '').replace(/\/+$/, '')

publicRouter.post(
  '/payments/initiate',
  bookingLimiter,
  validate({ body: z.object({ reference: referenceSchema, method: z.enum(METHODES) }) }),
  async (request, response) => {
    const ligne = await findByReference(request.body.reference.toUpperCase())
    if (!ligne) throw ApiError.notFound('Aucune demande ne correspond à cette référence.')
    if (ligne.payment_status === 'paid') throw ApiError.unprocessable('Cette demande est déjà payée.')
    if (!Number(ligne.awaiting_payment) || !ligne.payment_amount) {
      throw ApiError.unprocessable('Cette demande n’a pas de paiement à régler.')
    }
    if (!jekoPret()) throw new ApiError(503, 'Le paiement en ligne n’est pas disponible pour le moment.')

    const base = siteBase()
    const retour = `${base}/paiement/${ligne.reference}`
    const tentative = Date.now().toString(36)
    const resultat = await creerPaiement({
      amount: ligne.payment_amount,
      // Jèko veut une référence propre à chaque tentative : on la suffixe, le webhook retrouve la demande sans le suffixe.
      reference: `${ligne.reference}-${tentative}`,
      method: request.body.method,
      successUrl: `${retour}?retour=1`,
      errorUrl: `${retour}?retour=1&echec=1`,
    })
    const hoteRedirection = (() => { try { return new URL(resultat.redirectUrl).host } catch { return null } })()
    if (!resultat.ok) {
      console.error('Paiement non initié :', resultat.error)
      journaliserPaiement({ reference: ligne.reference, moyen: request.body.method, cause: resultat.error })
      const idTentative = await creerTentative({
        ligne, method: request.body.method, status: 'failed', jekoReference: `${ligne.reference}-${tentative}`,
        errorReason: resultat.errorReason, errorHttpStatus: resultat.httpStatus ?? null, errorMessage: resultat.error,
      })
      await enregistrerEvenement({ attemptId: idTentative, reference: ligne.reference, source: 'initiation', httpStatus: resultat.httpStatus ?? null, outcome: 'error', message: resultat.error })
      /* Hors production, la cause renvoyée par Jèko est jointe à la réponse pour faciliter le diagnostic (jamais de clé dedans). */
      throw new ApiError(502, 'Le paiement n’a pas pu être démarré. Réessayez dans un instant.', {
        details: config.isProduction ? null : [{ message: `Diagnostic : ${resultat.error}` }],
      })
    }
    await setPaymentAttempt(ligne.id, { method: request.body.method, providerId: resultat.id })
    const idTentative = await creerTentative({
      ligne, method: request.body.method, status: 'pending', mode: resultat.simule ? 'mock' : 'live',
      jekoReference: `${ligne.reference}-${tentative}`, paymentRequestId: resultat.id, jekoStatus: resultat.jekoStatus ?? (resultat.simule ? 'mock' : null),
      errorReason: resultat.errorReason ?? null, redirectHost: resultat.simule ? null : hoteRedirection,
    })
    await enregistrerEvenement({
      attemptId: idTentative, reference: ligne.reference, source: 'initiation', httpStatus: resultat.httpStatus ?? null, outcome: 'processed',
      statut: resultat.jekoStatus ?? null, jekoId: resultat.id,
      message: resultat.simule ? 'Demande simulée (aucun appel à Jèko).' : `Demande créée chez Jèko${resultat.errorReason ? ` — errorReason : ${resultat.errorReason}` : ''}.`,
    })

    // Simulation (hors production uniquement) : le paiement est « reçu » tout de suite.
    if (resultat.simule) {
      await confirmerPaiement(ligne)
      await majTentative(idTentative, { status: 'success' })
    }

    return sendData(response, { redirectUrl: resultat.redirectUrl, simulated: Boolean(resultat.simule) })
  },
)

/**
 * État du paiement, relu par la page de retour (la cliente peut revenir avant que le webhook n'arrive).
 *
 * Avec `?verifier=1` (envoyé par la page de retour pendant qu'elle attend), si la demande est encore en attente le
 * serveur interroge LUI-MÊME Jèko sur la tentative en cours — l'état est donc confirmé en quelques secondes même si
 * le webhook tarde ou a été perdu. Le succès n'est retenu que si Jèko répond « success » : le navigateur ne décide de rien.
 * Environ une interrogation de Jèko toutes les 2 secondes au plus, par tentative.
 */
publicRouter.get('/payments/status/:reference', async (request, response) => {
  const reference = referenceSchema.safeParse(request.params.reference)
  if (!reference.success) throw ApiError.unprocessable('Référence invalide.')
  let ligne = await findByReference(reference.data.toUpperCase())
  if (!ligne) throw ApiError.notFound('Aucune demande ne correspond à cette référence.')

  // « pending » mais aussi « failed » : un échec ancien (tentative abandonnée) ne doit pas masquer un paiement réussi ensuite.
  if (request.query.verifier === '1' && ['pending', 'failed'].includes(ligne.payment_status) && jekoPret() && !jekoSimule()) {
    try {
      for (const tentative of await tentativesEnAttente(ligne.reference)) {
        await verifierTentative(tentative, { journaliserAttente: false })
        ligne = (await findByReference(ligne.reference)) ?? ligne
        if (ligne.payment_status === 'paid') break
      }
    } catch (error) {
      // La relecture ne doit jamais empêcher de répondre : on renvoie simplement l'état connu.
      console.error('Relecture du paiement chez Jèko impossible :', error?.message)
    }
  }
  return sendData(response, serializePublic(ligne))
})

// Webhook Jèko : voir ./webhook.js (adresse : POST /api/payments/jeko/webhook).
publicRouter.use(webhookRouter)

export const _test = { confirmerPaiement, jekoSimule }
