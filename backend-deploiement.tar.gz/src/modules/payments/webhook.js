import { Router } from 'express'

import { ApiError } from '../../lib/ApiError.js'
import { sendData } from '../../lib/http.js'
import { diagnosticSignature, lireWebhook, signatureValide } from '../../lib/jeko.js'
import { findByReference } from '../booking-requests/model.js'
import { corpsEnTexte, enregistrerEvenement, trouverTentative } from './journal.js'
import { appliquerStatutJeko } from './service.js'

/**
 * Webhook Jèko — l'adresse à enregistrer dans le tableau de bord Jèko (« Ajouter un webhook magasin ») est :
 *
 *     https://<domaine de l'API>/api/payments/jeko/webhook
 *
 * Ce que fait ce fichier, dans l'ordre :
 *  1. vérifie la signature HMAC-SHA256 (en-tête Jeko-Signature, corps brut, secret JEKO_WEBHOOK_SECRET) : sinon 401 ;
 *  2. retrouve la demande par la référence que nous avons envoyée à Jèko (transactionDetails.reference) ;
 *  3. si Jèko annonce « success » : la demande est payée UNE SEULE FOIS, même si la notification est rejouée.
 *     La finalisation (voir booking-requests › finaliserDemande) crée la fiche cliente et le rendez-vous, prévient
 *     le salon, puis envoie à la cliente la confirmation de paiement sur TOUS les canaux activés dans la messagerie du
 *     salon : WhatsApp (QR/Baileys), SMS et e-mail — sans jamais bloquer la réponse à Jèko ;
 *  4. si Jèko annonce un échec : la tentative est marquée échouée, aucun message de confirmation n'est envoyé ;
 *  5. chaque notification reçue est inscrite dans le journal technique (rubrique « Paiements Jèko » du dashboard).
 *
 * Jèko réessaie sur une réponse 5xx ou un délai dépassé, pas sur un 4xx : les erreurs de traitement répondent donc 500.
 */
export const webhookRouter = Router()

/**
 * Webhook Jèko. Authentifié par la signature HMAC du corps BRUT ; sans secret configuré, il est refusé :
 * n'importe qui pourrait sinon « payer » une demande en appelant cette adresse.
 */
webhookRouter.post('/payments/jeko/webhook', async (request, response) => {
  const debut = Date.now()
  const typeEvenement = request.get('Jeko-Event') || null
  if (!signatureValide(request.rawBody, request.get('Jeko-Signature'))) {
    await enregistrerEvenement({
      source: 'webhook', type: typeEvenement, httpStatus: 401, signatureValide: false, outcome: 'rejected',
      message: diagnosticSignature(request.rawBody, request.get('Jeko-Signature')), dureeMs: Date.now() - debut,
    })
    throw new ApiError(401, 'Signature invalide.')
  }
  const evenement = lireWebhook(request.body)
  const reference = evenement.reference.split('-').slice(0, 2).join('-').toUpperCase()
  const corps = corpsEnTexte(request.body)
  const journal = (champs) =>
    enregistrerEvenement({
      source: 'webhook', type: typeEvenement, httpStatus: 200, signatureValide: true, statut: evenement.statut || null,
      jekoId: evenement.paymentRequestId || evenement.transactionId || null, reference: reference || null, corps, dureeMs: Date.now() - debut, ...champs,
    })

  try {
    // Ni un virement, ni un événement autre que le paiement d'une transaction : on accuse réception, sans rien faire.
    if ((typeEvenement && typeEvenement !== 'TRANSACTION_COMPLETED') || (evenement.type && evenement.type !== 'payment')) {
      await journal({ outcome: 'ignored', message: `Événement « ${typeEvenement ?? evenement.type} » sans effet sur les paiements du site.` })
      return sendData(response, { received: true, matched: false })
    }
    const ligne = reference ? await findByReference(reference) : null
    const tentative = await trouverTentative({ jekoReference: evenement.reference || null, paymentRequestId: evenement.paymentRequestId || null, reference: ligne ? ligne.reference : null })
    if (!ligne) {
      await journal({ attemptId: tentative?.id ?? null, outcome: 'unmatched', message: 'Aucune demande ne correspond à la référence reçue.' })
      return sendData(response, { received: true, matched: false })
    }
    const resultat = await appliquerStatutJeko({
      tentative, ligne, statutBrut: evenement.statut, transactionId: evenement.transactionId, paymentRequestId: evenement.paymentRequestId, montant: evenement.montant, devise: evenement.devise,
    })
    await journal({ attemptId: tentative?.id ?? null, outcome: resultat.outcome, message: resultat.message })
    return sendData(response, { received: true, matched: true })
  } catch (error) {
    // Jèko réessaie sur une réponse 5xx : on garde la trace puis on laisse l'erreur remonter.
    await journal({ outcome: 'error', httpStatus: 500, message: `Traitement en échec : ${String(error?.message ?? error).slice(0, 300)}` })
    throw error
  }
})

