import { ApiError } from '../../lib/ApiError.js'
import { consulterPaiement, normaliserStatut } from '../../lib/jeko.js'
import { findById, findByReference, markPaid, markPaymentFailed } from '../booking-requests/model.js'
import { controlerPaiement } from '../booking-requests/autoConfirm.js'
import { finaliserDemande } from '../booking-requests/routes.js'
import { enregistrerEvenement, estDerniereTentative, majTentative } from './journal.js'

/** Finalise une demande venant d'être payée — une seule fois, même si le webhook est rejoué. */
export async function confirmerPaiement(ligne, { controle = { ok: true }, transactionId = null } = {}) {
  const premiere = await markPaid(ligne.id)
  if (premiere) {
    const payee = await findById(ligne.id)
    await finaliserDemande(payee, { controle, transactionId })
  }
  return premiere
}

/** Le montant annoncé correspond-il (en FCFA ou en centimes) ? Sans montant, on ne peut rien dire. */
export const montantCoherent = (recu, attendu) =>
  recu === null || recu === undefined || !attendu || [Number(attendu), Number(attendu) * 100].includes(Number(recu))

/**
 * Applique à une tentative (et à sa demande) un statut RAPPORTÉ PAR JÈKO — webhook signé ou lecture directe chez Jèko.
 * C'est le seul endroit qui peut marquer un paiement réussi, et il exige un statut explicite « success ».
 *
 * @returns {Promise<{ outcome: string, message: string, statut: string|null, change: boolean }>}
 */
export async function appliquerStatutJeko({ tentative, ligne, statutBrut, transactionId = null, paymentRequestId = null, montant = null, devise = null, errorReason = null }) {
  const statut = normaliserStatut(statutBrut)
  const champs = { jekoStatus: statutBrut || undefined, transactionId: transactionId || undefined, paymentRequestId: paymentRequestId || undefined, errorReason: errorReason || undefined }
  // Montant ET devise annoncés par Jèko contre les frais de consultation attendus : sinon, paiement noté mais pas de confirmation automatique.
  const controle = controlerPaiement({ montant, devise, attendu: tentative?.amount ?? ligne?.payment_amount })
  const alerteMontant = !montantCoherent(montant, tentative?.amount ?? ligne?.payment_amount) || !controle.ok
  const noteMontant = alerteMontant ? ` Montant annoncé (${montant}${devise ? ` ${devise}` : ''}) différent du paiement attendu (${tentative?.amount ?? ligne?.payment_amount} FCFA) : pas de confirmation automatique.` : ''

  if (statut === 'success') {
    if (!ligne) return { outcome: 'unmatched', message: `Paiement réussi chez Jèko mais aucune demande ne correspond.${noteMontant}`, statut, change: false }
    const premiere = await confirmerPaiement(ligne, { controle, transactionId })
    await majTentative(tentative?.id, { ...champs, status: 'success', amountWarning: alerteMontant ? 1 : undefined, verifie: true })
    return {
      outcome: premiere ? 'processed' : 'duplicate',
      message: premiere ? `Paiement confirmé, demande finalisée.${noteMontant}` : `Paiement déjà enregistré (notification rejouée), sans effet.${noteMontant}`,
      statut,
      change: Boolean(premiere) || tentative?.status !== 'success',
    }
  }

  if (['failed', 'cancelled', 'expired'].includes(statut)) {
    if (tentative?.status === 'success' || ligne?.payment_status === 'paid') {
      return { outcome: 'ignored', message: `Statut « ${statutBrut} » ignoré : la demande est déjà payée.`, statut, change: false }
    }
    await majTentative(tentative?.id, { ...champs, status: statut, verifie: true })
    if (ligne && (!tentative || (await estDerniereTentative(tentative)))) await markPaymentFailed(ligne.id)
    return { outcome: 'processed', message: `Paiement non abouti (${statutBrut}).${errorReason ? ` Motif Jèko : ${errorReason}.` : ''}`, statut, change: tentative?.status !== statut }
  }

  await majTentative(tentative?.id, { ...champs, verifie: true })
  return { outcome: 'ignored', message: statut === 'pending' ? 'Toujours en attente chez Jèko.' : `Statut « ${statutBrut || 'vide'} » non terminal : aucune action.`, statut, change: false }
}

/**
 * Vérifie auprès de Jèko l'état d'une tentative et l'applique. Journalise la vérification.
 * Jamais de succès déclaré sans que Jèko ne l'ait dit.
 */
export async function verifierTentative(tentative, { journaliserAttente = true } = {}) {
  if (tentative.mode === 'mock') throw ApiError.unprocessable('Tentative simulée : rien à vérifier chez Jèko.')
  if (!tentative.jeko_payment_request_id) throw ApiError.unprocessable('Cette tentative n’a pas d’identifiant Jèko (la création a été refusée) : il n’y a rien à vérifier.')
  const t0 = Date.now()
  const lu = await consulterPaiement(tentative.jeko_payment_request_id)
  const ligne = tentative.booking_request_id ? await findByReference(tentative.request_reference) : null

  if (!lu.ok) {
    await majTentative(tentative.id, { verifie: true })
    await enregistrerEvenement({ attemptId: tentative.id, reference: tentative.request_reference, source: 'verification', httpStatus: lu.httpStatus || null, outcome: 'error', message: lu.erreur, dureeMs: Date.now() - t0, jekoId: tentative.jeko_payment_request_id })
    return { ok: false, message: lu.erreur }
  }
  // La demande peut rester « pending » pendant que sa transaction est déjà terminée : la transaction fait foi.
  const statutTransaction = normaliserStatut(lu.transactionStatus)
  const statutLu = normaliserStatut(lu.status) === 'pending' && ['success', 'failed'].includes(statutTransaction) ? lu.transactionStatus : lu.status
  const r = await appliquerStatutJeko({
    tentative, ligne, statutBrut: statutLu, transactionId: lu.transactionId, montant: lu.amount, devise: lu.devise, errorReason: lu.errorReason,
  })
  // Relecture de la page de retour (toutes les 3 s) : « toujours en attente » ne mérite pas une ligne de journal à chaque fois.
  if (!journaliserAttente && r.outcome === 'ignored' && r.statut === 'pending') return { ok: true, message: r.message, statut: r.statut, change: false }
  await enregistrerEvenement({
    attemptId: tentative.id, reference: tentative.request_reference, source: 'verification', httpStatus: lu.httpStatus, outcome: r.outcome,
    statut: statutLu, jekoId: tentative.jeko_payment_request_id, message: r.message, dureeMs: Date.now() - t0,
  })
  return { ok: true, message: r.message, statut: r.statut, change: r.change }
}
