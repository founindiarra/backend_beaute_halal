import { execute, query, queryOne } from '../../config/database.js'

/**
 * Journal des paiements Jèko : une ligne par tentative (`payment_attempts`) et un journal technique
 * (`payment_events`) des créations, webhooks et vérifications de statut.
 *
 * Règle absolue : le journal ne casse JAMAIS un paiement. Toute écriture ici est protégée : en cas de panne
 * (table absente avant la migration 014, base indisponible…) elle est signalée dans la console et ignorée.
 * Aucun secret n'y entre : ni clé, ni signature, ni secret de webhook ; les numéros reçus de Jèko sont masqués.
 */

const coupe = (valeur, n) => (valeur === null || valeur === undefined || valeur === '' ? null : String(valeur).slice(0, n))

const SENSIBLE = /(secret|signature|api[-_]?key|token|password|authorization)/i
const TELEPHONE = /(phone|msisdn|counterpartidentifier|payer)/i

/** Masque un numéro : on garde les 3 derniers chiffres. */
const masquerNumero = (valeur) => {
  const chiffres = String(valeur ?? '').replace(/\D/g, '')
  return chiffres.length > 4 ? `${'•'.repeat(Math.max(0, chiffres.length - 3))}${chiffres.slice(-3)}` : '•••'
}

/** Copie un corps JSON sans donnée sensible (clés, secrets, jetons) et avec les numéros masqués. */
export function nettoyerCorps(valeur, profondeur = 0) {
  if (profondeur > 6) return '…'
  if (Array.isArray(valeur)) return valeur.slice(0, 20).map((v) => nettoyerCorps(v, profondeur + 1))
  if (valeur && typeof valeur === 'object') {
    const sortie = {}
    for (const [cle, v] of Object.entries(valeur)) {
      if (SENSIBLE.test(cle)) sortie[cle] = '[masqué]'
      else if (/^store(id|reference)$/i.test(cle) && typeof v === 'string') sortie[cle] = `…${v.slice(-4)}`
      else if (TELEPHONE.test(cle) && (typeof v === 'string' || typeof v === 'number')) sortie[cle] = masquerNumero(v)
      else sortie[cle] = nettoyerCorps(v, profondeur + 1)
    }
    return sortie
  }
  return typeof valeur === 'string' ? valeur.slice(0, 500) : valeur
}

/** Corps en texte, nettoyé et tronqué à 4 000 caractères. */
export function corpsEnTexte(json) {
  try {
    if (json === null || json === undefined) return null
    return JSON.stringify(nettoyerCorps(json), null, 2).slice(0, 4000)
  } catch {
    return null
  }
}

/** Enregistre une tentative ; renvoie son id, ou null si le journal est indisponible. */
export async function creerTentative({ ligne, method, amount, status = 'pending', mode = 'live', jekoReference = null, paymentRequestId = null, jekoStatus = null, errorReason = null, errorHttpStatus = null, errorMessage = null, redirectHost = null }) {
  try {
    const r = await execute(
      `INSERT INTO payment_attempts
         (booking_request_id, request_reference, customer_name, customer_phone, method, amount, status, mode,
          jeko_reference, jeko_payment_request_id, jeko_status, error_reason, error_http_status, error_message, redirect_host,
          completed_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        ligne.id, ligne.reference, coupe([ligne.first_name, ligne.last_name].filter(Boolean).join(' '), 160), coupe(ligne.phone, 30),
        coupe(method, 12), amount ?? ligne.payment_amount ?? null, status, mode,
        coupe(jekoReference, 80), coupe(paymentRequestId, 80), coupe(jekoStatus, 30),
        coupe(errorReason, 255), errorHttpStatus ?? null, coupe(errorMessage, 500), coupe(redirectHost, 120),
        status === 'success' ? new Date() : null,
      ],
    )
    return r.insertId
  } catch (error) {
    console.error('Journal paiement (tentative) indisponible :', error?.code ?? error?.message)
    return null
  }
}

/** Met à jour une tentative (seuls les champs fournis changent). */
export async function majTentative(id, champs) {
  if (!id) return
  const colonnes = {
    status: 'status', jekoStatus: 'jeko_status', transactionId: 'jeko_transaction_id', paymentRequestId: 'jeko_payment_request_id',
    errorReason: 'error_reason', errorHttpStatus: 'error_http_status', errorMessage: 'error_message', amountWarning: 'amount_warning',
  }
  const sets = []
  const valeurs = []
  for (const [cle, colonne] of Object.entries(colonnes)) {
    if (champs[cle] === undefined) continue
    sets.push(`${colonne} = ?`)
    valeurs.push(['jekoStatus', 'transactionId', 'paymentRequestId', 'errorReason', 'errorMessage'].includes(cle) ? coupe(champs[cle], cle === 'errorMessage' ? 500 : 255) : champs[cle])
  }
  if (champs.status === 'success') sets.push('completed_at = COALESCE(completed_at, NOW())')
  if (champs.verifie) sets.push('last_checked_at = NOW()')
  if (!sets.length) return
  try {
    await execute(`UPDATE payment_attempts SET ${sets.join(', ')} WHERE id = ?`, [...valeurs, id])
  } catch (error) {
    console.error('Journal paiement (mise à jour) indisponible :', error?.code ?? error?.message)
  }
}

/** Ajoute une ligne au journal technique. */
export async function enregistrerEvenement({ attemptId = null, reference = null, source, type = null, httpStatus = null, signatureValide = null, outcome, statut = null, jekoId = null, message = null, dureeMs = null, corps = null }) {
  try {
    await execute(
      `INSERT INTO payment_events
         (attempt_id, request_reference, source, event_type, http_status, signature_valid, outcome, reported_status, jeko_id, message, duration_ms, payload)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        attemptId, coupe(reference, 30), source, coupe(type, 40), httpStatus, signatureValide === null ? null : signatureValide ? 1 : 0,
        outcome, coupe(statut, 30), coupe(jekoId, 80), coupe(message, 500), dureeMs, corps,
      ],
    )
    // Les rejets (signature invalide) viennent d'une route publique : on ne les garde que 60 jours.
    if (outcome === 'rejected') await execute("DELETE FROM payment_events WHERE outcome = 'rejected' AND created_at < (NOW() - INTERVAL 60 DAY)")
  } catch (error) {
    console.error('Journal paiement (événement) indisponible :', error?.code ?? error?.message)
  }
}

export const trouverTentative = ({ jekoReference, paymentRequestId, reference }) =>
  queryOne(
    `SELECT * FROM payment_attempts
      WHERE (? IS NOT NULL AND jeko_reference = ?) OR (? IS NOT NULL AND jeko_payment_request_id = ?)
      ORDER BY id DESC LIMIT 1`,
    [jekoReference || null, jekoReference || null, paymentRequestId || null, paymentRequestId || null],
  ).then(async (t) => t ?? (reference ? queryOne('SELECT * FROM payment_attempts WHERE request_reference = ? ORDER BY id DESC LIMIT 1', [reference]) : null))
  .catch(() => null)

/** Dernière tentative réelle encore en attente d'une demande, pas relue chez Jèko depuis ~2 secondes (la colonne est à la seconde près). */
export const tentativeEnAttente = (reference) =>
  queryOne(
    `SELECT * FROM payment_attempts
      WHERE request_reference = ? AND mode = 'live' AND status = 'pending' AND jeko_payment_request_id IS NOT NULL
        AND (last_checked_at IS NULL OR last_checked_at < (NOW() - INTERVAL 1 SECOND))
      ORDER BY id DESC LIMIT 1`,
    [reference],
  ).catch(() => null)

/**
 * Toutes les tentatives « en cours » d'une demande (la plus récente d'abord) : une cliente qui a payé, puis recliqué sur
 * « Payer » en croyant que ça n'avait pas marché, a deux tentatives — c'est la première qui a été payée.
 */
export const tentativesEnAttente = (reference) =>
  query(
    `SELECT * FROM payment_attempts
      WHERE request_reference = ? AND mode = 'live' AND status = 'pending' AND jeko_payment_request_id IS NOT NULL
        AND (last_checked_at IS NULL OR last_checked_at < (NOW() - INTERVAL 1 SECOND))
      ORDER BY id DESC LIMIT 6`,
    [reference],
  ).catch(() => [])

/** La tentative est-elle la plus récente de sa demande ? (un échec ancien ne doit pas condamner la demande) */
export async function estDerniereTentative(tentative) {
  try {
    const r = await queryOne('SELECT MAX(id) AS dernier FROM payment_attempts WHERE request_reference = ?', [tentative.request_reference])
    return !r?.dernier || Number(r.dernier) === Number(tentative.id)
  } catch {
    return true
  }
}

export { query }
