import { unlink } from 'node:fs/promises'

import { writeFile } from 'node:fs/promises'
import { randomBytes } from 'node:crypto'

import express, { Router } from 'express'
import { z } from 'zod'

import { ApiError } from '../../lib/ApiError.js'
import { sendCreated, sendNoContent } from '../../lib/http.js'
import { absoluteUrl } from '../../lib/url.js'
import { config } from '../../config/env.js'
import { slugify } from '../../lib/slug.js'
import { publicUploadPath, uploadAbsolutePath, uploadImage, uploadVideo } from '../../middleware/upload.js'
import { validate } from '../../middleware/validate.js'

export const adminRouter = Router()

/**
 * Dépôt d'une image (champ « image », multipart/form-data).
 * Renvoie le chemin à enregistrer dans image_url (ex. « /uploads/xxx.jpg »)
 * ainsi que l'URL complète pour l'aperçu immédiat.
 */
adminRouter.post('/uploads', (request, response, next) => {
  uploadImage(request, response, (error) => {
    if (error) return next(error)
    if (!request.file) return next(ApiError.badRequest('Aucun fichier reçu (champ « image »).'))

    const path = publicUploadPath(request.file.filename)
    return sendCreated(response, {
      path,
      url: absoluteUrl(path),
      filename: request.file.filename,
      size: request.file.size,
      mimeType: request.file.mimetype,
    })
  })
})

/**
 * Dépôt d'une image en JSON (base64) : { filename, data }. Certains hébergeurs bloquent (403, sans réponse lisible)
 * les envois « multipart/form-data » avec fichier ; un simple POST JSON passe partout. Même résultat que POST /uploads.
 * Le type réel est lu dans les premiers octets du fichier, jamais dans ce que déclare le navigateur.
 */
const SIGNATURES = [
  { ext: '.jpg', mime: 'image/jpeg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { ext: '.png', mime: 'image/png', test: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { ext: '.webp', mime: 'image/webp', test: (b) => b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP' },
]
adminRouter.post(
  '/uploads/base64',
  express.json({ limit: `${Math.ceil((config.upload.maxBytes * 4) / 3 / 1024 / 1024) + 1}mb` }),
  async (request, response, next) => {
    try {
      const { filename, data } = request.body ?? {}
      if (typeof data !== 'string' || !data) throw ApiError.badRequest('Aucune image reçue.')
      const buffer = Buffer.from(data.replace(/^data:[^,]*,/, ''), 'base64')
      if (!buffer.length) throw ApiError.badRequest('Image vide ou illisible.')
      if (buffer.length > config.upload.maxBytes) {
        throw ApiError.badRequest(`Image trop lourde (${Math.round(config.upload.maxBytes / 1024 / 1024)} Mo maximum).`)
      }
      const type = SIGNATURES.find((t) => t.test(buffer))
      if (!type) throw ApiError.badRequest('Format accepté : JPEG, PNG ou WebP.')
      const base = slugify(String(filename ?? '').replace(/\.[^.]*$/, '')) || 'image'
      const name = `${Date.now()}-${randomBytes(4).toString('hex')}-${base}${type.ext}`
      await writeFile(uploadAbsolutePath(name), buffer)
      const path = publicUploadPath(name)
      return sendCreated(response, { path, url: absoluteUrl(path), filename: name, size: buffer.length, mimeType: type.mime })
    } catch (error) {
      return next(error)
    }
  },
)

/** Dépôt d'une vidéo d'ambiance (champ « video », MP4 ou WebM). */
adminRouter.post('/uploads/video', (request, response, next) => {
  uploadVideo(request, response, (error) => {
    if (error) return next(error)
    if (!request.file) return next(ApiError.badRequest('Aucun fichier reçu (champ « video »).'))
    const path = publicUploadPath(request.file.filename)
    return sendCreated(response, {
      path,
      url: absoluteUrl(path),
      filename: request.file.filename,
      size: request.file.size,
      mimeType: request.file.mimetype,
    })
  })
})

adminRouter.delete(
  '/uploads/:filename',
  validate({
    params: z.object({
      filename: z
        .string()
        .regex(/^[A-Za-z0-9._-]+$/, 'Nom de fichier invalide.')
        .max(200),
    }),
  }),
  async (request, response) => {
    try {
      await unlink(uploadAbsolutePath(request.params.filename))
    } catch (error) {
      if (error.code === 'ENOENT') throw ApiError.notFound('Ce fichier n’existe pas.')
      throw error
    }
    return sendNoContent(response)
  },
)
