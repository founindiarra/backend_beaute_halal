/**
 * Méthodes de pose d'une INSTALLATION de locks (étape « Méthode » du site, juste après le type de locks).
 * Le serveur n'accepte que ces identifiants et écrit le libellé exact (selon le type) dans le message du salon.
 * Les textes d'aide et les conseils vivent côté site ; ici : seulement ce qu'il faut pour valider et nommer.
 */
export const METHODE_IDS = ['interlocking', 'braid', 'twist', 'broderie']

const GENERIQUES = { interlocking: 'Interlocking', braid: 'Braid', twist: 'Twist', broderie: 'Broderie' }
const LIBELLES = {
  micro: { interlocking: 'Micro interlocking', braid: 'Micro braid', twist: 'Micro twist', broderie: 'Broderie' },
  small: { interlocking: 'Small interlocking', braid: 'Small micro braid', twist: 'Small micro twist', broderie: 'Small broderie' },
  traditionnels: GENERIQUES,
}

/** « Micro interlocking », « Small broderie »… ; null si la méthode n'existe pas. */
export const libelleMethode = (typeId, methodeId) => (METHODE_IDS.includes(methodeId) ? (LIBELLES[typeId] ?? GENERIQUES)[methodeId] : null)
