import { Router } from 'express'
import { z } from 'zod'

import { config } from '../../config/env.js'
import { query, queryOne } from '../../config/database.js'
import { ApiError } from '../../lib/ApiError.js'
import { paginationMeta, readPagination, sendData, sendList } from '../../lib/http.js'
import { METHODES, jekoConfigurationManquante, jekoSimule } from '../../lib/jeko.js'
import { jekoActionLimiter, jekoLimiter } from '../../middleware/rateLimit.js'
import { getQuery, validate } from '../../middleware/validate.js'
import { verifierTentative } from '../payments/service.js'

/**
 * Rubrique « Paiements Jèko » du dashboard.
 *
 * Le droit « jeko » est vérifié dans routes/index.js (garde par préfixe) : réservé à l'administratrice, jamais accordable
 * à un agent. Tout vient de la base (tables payment_attempts / payment_events, remplies par le module payments) ;
 * la seule sortie réseau est la vérification d'un statut chez Jèko, déclenchée par un clic.
 * Aucune clé, aucun secret, aucune signature ne sort jamais d'ici.
 */
export const adminRouter = Router()
adminRouter.use('/jeko', jekoLimiter)

const STATUTS = ['pending', 'success', 'failed', 'cancelled', 'expired']
const PAR_MODE_LIVE = "mode = 'live'"

const tentative = (r) => ({
  id: r.id,
  requestId: r.booking_request_id ?? null,
  requestReference: r.request_reference,
  customerName: r.customer_name || null,
  customerPhone: r.customer_phone || null,
  method: r.method || null,
  amount: r.amount === null ? null : Number(r.amount),
  currency: r.currency,
  status: r.status,
  simulated: r.mode === 'mock',
  jekoStatus: r.jeko_status || null,
  amountWarning: Boolean(Number(r.amount_warning)),
  hasError: r.status === 'failed' || Boolean(r.error_message || r.error_reason),
  errorReason: r.error_reason || null,
  createdAt: r.created_at,
  completedAt: r.completed_at ?? null,
  lastCheckedAt: r.last_checked_at ?? null,
})

const evenement = (r) => ({
  id: r.id,
  attemptId: r.attempt_id ?? null,
  requestReference: r.request_reference || null,
  source: r.source,
  eventType: r.event_type || null,
  httpStatus: r.http_status ?? null,
  signatureValid: r.signature_valid === null || r.signature_valid === undefined ? null : Boolean(Number(r.signature_valid)),
  outcome: r.outcome,
  reportedStatus: r.reported_status || null,
  jekoId: r.jeko_id || null,
  message: r.message || null,
  durationMs: r.duration_ms ?? null,
  payload: r.payload || null,
  createdAt: r.created_at,
})

/** Critères de la liste (filtres) → clause WHERE + paramètres. */
function filtres(q) {
  const where = []
  const params = []
  if (q.status) { where.push('status = ?'); params.push(q.status) }
  if (q.method) { where.push('method = ?'); params.push(q.method) }
  if (q.mode === 'live' || q.mode === 'mock') { where.push('mode = ?'); params.push(q.mode) }
  if (q.from) { where.push('created_at >= ?'); params.push(`${q.from} 00:00:00`) }
  if (q.to) { where.push('created_at <= ?'); params.push(`${q.to} 23:59:59`) }
  if (q.errors) where.push("(status = 'failed' OR error_message IS NOT NULL OR error_reason IS NOT NULL)")
  if (q.search) {
    const m = `%${q.search.replace(/[%_\\]/g, (c) => `\\${c}`)}%`
    where.push('(request_reference LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ? OR jeko_reference LIKE ? OR jeko_payment_request_id LIKE ? OR jeko_transaction_id LIKE ?)')
    params.push(m, m, m, m, m, m)
  }
  return { sql: where.length ? `WHERE ${where.join(' AND ')}` : '', params }
}

const listeSchema = z.object({
  status: z.enum(STATUTS).optional(),
  method: z.enum(METHODES).optional(),
  mode: z.enum(['live', 'mock']).optional(),
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  search: z.string().trim().max(80).optional(),
  errors: z.enum(['1']).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
})

/** Pistes de diagnostic, déduites uniquement de ce que le journal sait. Jamais une certitude affichée comme telle. */
function diagnostics(t, evenements) {
  const pistes = []
  const ajout = (niveau, texte) => pistes.push({ level: niveau, text: texte })
  const age = (Date.now() - new Date(t.created_at).getTime()) / 60000
  const webhooks = evenements.filter((e) => e.source === 'webhook')
  const mobileUssd = ['mtn', 'moov'].includes(t.method)

  if (t.error_http_status === 401 || t.error_http_status === 403) {
    ajout('danger', 'Jèko a refusé nos clés (HTTP ' + t.error_http_status + ') : vérifier JEKO_API_KEY, JEKO_API_KEY_ID et JEKO_STORE_ID dans le .env du serveur — ils doivent venir du même magasin Jèko.')
  } else if (t.error_http_status === 400 || t.error_http_status === 422 || t.error_http_status === 404) {
    ajout('danger', `Jèko a rejeté la demande (HTTP ${t.error_http_status}) : moyen de paiement non activé sur le magasin, montant ou URL de retour refusés. SITE_URL doit être l’adresse https du site.`)
  } else if (t.error_http_status === 0) {
    ajout('danger', 'Le serveur n’a pas pu joindre Jèko (réseau, délai dépassé). Réessayer ; si cela persiste, l’hébergeur bloque peut-être les appels sortants.')
  } else if (t.error_http_status >= 500) {
    ajout('warn', `Jèko a répondu par une erreur serveur (HTTP ${t.error_http_status}) : incident côté Jèko, à réessayer plus tard.`)
  }
  if (t.status === 'pending' && mobileUssd && age > 10) {
    ajout('warn', `Avec ${t.method === 'mtn' ? 'MTN' : 'Moov'}, Jèko ne renvoie plus la cliente chez l’opérateur : la confirmation se fait par USSD (${t.method === 'mtn' ? '*133#' : 'menu Moov Money'}). Si l’opérateur répond « Aucune approbation en attente », c’est que la demande n’a pas (ou plus) atteint ce numéro : numéro saisi sur la page Jèko différent de celui du compte Mobile Money, demande expirée, ou demande non transmise à l’opérateur. Relancez un paiement en vérifiant le numéro, puis, si cela se reproduit, transmettez au support Jèko l’identifiant de la demande (voir « Dossier pour le support Jèko »).`)
  }
  if (t.status === 'pending' && age > 15 && !webhooks.some((e) => e.signature_valid === 1)) {
    ajout('warn', 'Aucune notification Jèko valide reçue pour cette tentative. Utilisez « Vérifier auprès de Jèko » ; si le statut y est déjà « success », contrôlez l’abonnement webhook (adresse et JEKO_WEBHOOK_SECRET).')
  }
  if (webhooks.some((e) => e.signature_valid === 0)) {
    ajout('danger', 'Au moins un webhook a été refusé pour signature invalide : le secret du serveur ne correspond pas à celui de l’abonnement Jèko.')
  }
  if (Number(t.amount_warning)) {
    ajout('warn', 'Le montant annoncé par Jèko diffère du montant attendu : à vérifier dans le tableau de bord Jèko avant tout geste commercial.')
  }
  if (t.status === 'success') ajout('ok', 'Paiement confirmé par Jèko (notification signée ou lecture directe du statut).')
  if (t.mode === 'mock') ajout('info', 'Tentative simulée : aucun appel à Jèko, aucun argent.')
  return pistes
}

function dossierSupport(t, evenements) {
  const lignes = [
    'Dossier support Jèko — Beauté Halal',
    `Moyen de paiement : ${t.method ?? '—'}`,
    `Montant : ${t.amount ?? '—'} ${t.currency}`,
    `Créée le : ${new Date(t.created_at).toISOString()}`,
    `Référence envoyée à Jèko : ${t.jeko_reference ?? '—'}`,
    `Identifiant de la demande de paiement : ${t.jeko_payment_request_id ?? '—'}`,
    `Identifiant de transaction : ${t.jeko_transaction_id ?? '—'}`,
    `Dernier statut Jèko : ${t.jeko_status ?? '—'}`,
    `errorReason : ${t.error_reason ?? '—'}`,
    `Code HTTP d’erreur : ${t.error_http_status ?? '—'}`,
    `Notifications reçues : ${evenements.filter((e) => e.source === 'webhook').length}`,
  ]
  return lignes.join('\n')
}

/** Santé de la configuration : présence des variables (jamais leurs valeurs). */
function configuration(request) {
  const hote = (() => { try { return new URL(config.jeko.baseUrl).host } catch { return null } })()
  const manquantes = jekoConfigurationManquante()
  return {
    ready: jekoSimule() || manquantes.length === 0,
    simulated: jekoSimule(),
    missing: manquantes,
    webhookSecretSet: Boolean(config.jeko.webhookSecret),
    apiHost: hote,
    storeIdSuffix: config.jeko.storeId ? `…${String(config.jeko.storeId).slice(-4)}` : null,
    siteUrl: config.siteUrl || null,
    siteUrlSecure: /^https:\/\//i.test(config.siteUrl || ''),
    webhookUrl: `${request.protocol}://${request.get('host')}/api/payments/jeko/webhook`,
    environment: config.env,
  }
}

adminRouter.get('/jeko/overview', async (request, response) => {
  const lignes = await query(`SELECT status, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS total FROM payment_attempts WHERE ${PAR_MODE_LIVE} GROUP BY status`)
  const parStatut = Object.fromEntries(STATUTS.map((s) => [s, { count: 0, amount: 0 }]))
  for (const l of lignes) if (parStatut[l.status]) parStatut[l.status] = { count: Number(l.n), amount: Number(l.total) }
  const annules = { count: parStatut.cancelled.count + parStatut.expired.count, amount: parStatut.cancelled.amount + parStatut.expired.amount }

  const periodes = await queryOne(
    `SELECT COALESCE(SUM(CASE WHEN DATE(completed_at) = CURDATE() THEN amount END), 0) AS aujourdhui,
            COALESCE(SUM(CASE WHEN completed_at >= (NOW() - INTERVAL 30 DAY) THEN amount END), 0) AS trente_jours
       FROM payment_attempts WHERE ${PAR_MODE_LIVE} AND status = 'success'`,
  )
  const parMoyen = await query(
    `SELECT method, COUNT(*) AS n,
            SUM(status = 'success') AS reussis, COALESCE(SUM(CASE WHEN status = 'success' THEN amount END), 0) AS encaisse,
            SUM(status = 'pending') AS attente, SUM(status = 'failed') AS echecs
       FROM payment_attempts WHERE ${PAR_MODE_LIVE} GROUP BY method ORDER BY n DESC`,
  )
  const a_verifier = await queryOne(
    `SELECT COUNT(*) AS n FROM payment_attempts
      WHERE ${PAR_MODE_LIVE} AND status = 'pending' AND jeko_payment_request_id IS NOT NULL AND created_at < (NOW() - INTERVAL 15 MINUTE)`,
  )
  const hooks = await queryOne(
    `SELECT COUNT(*) AS n24, MAX(created_at) AS dernier,
            SUM(outcome = 'rejected') AS rejetes24, SUM(outcome = 'error') AS erreurs24,
            (SELECT MAX(created_at) FROM payment_events WHERE source = 'webhook' AND signature_valid = 1) AS dernier_valide
       FROM payment_events WHERE source = 'webhook' AND created_at >= (NOW() - INTERVAL 24 HOUR)`,
  )
  const dernierWebhook = await queryOne("SELECT MAX(created_at) AS dernier, MAX(CASE WHEN signature_valid = 1 THEN created_at END) AS valide FROM payment_events WHERE source = 'webhook'")
  const simules = await queryOne("SELECT COUNT(*) AS n FROM payment_attempts WHERE mode = 'mock'")

  return sendData(response, {
    total: Object.values(parStatut).reduce((s, v) => s + v.count, 0),
    success: parStatut.success,
    pending: parStatut.pending,
    failed: parStatut.failed,
    cancelled: annules,
    collected: { total: parStatut.success.amount, today: Number(periodes?.aujourdhui ?? 0), last30Days: Number(periodes?.trente_jours ?? 0) },
    toVerify: Number(a_verifier?.n ?? 0),
    byMethod: parMoyen.map((m) => ({ method: m.method, count: Number(m.n), success: Number(m.reussis ?? 0), collected: Number(m.encaisse), pending: Number(m.attente ?? 0), failed: Number(m.echecs ?? 0) })),
    webhooks: {
      last24h: Number(hooks?.n24 ?? 0),
      rejected24h: Number(hooks?.rejetes24 ?? 0),
      errors24h: Number(hooks?.erreurs24 ?? 0),
      lastReceivedAt: dernierWebhook?.dernier ?? null,
      lastValidAt: dernierWebhook?.valide ?? null,
    },
    simulated: Number(simules?.n ?? 0),
    config: configuration(request),
  })
})

adminRouter.get('/jeko/payments', validate({ query: listeSchema }), async (request, response) => {
  const q = getQuery(request)
  const pagination = readPagination({ query: q })
  const { sql, params } = filtres(q)
  const total = (await queryOne(`SELECT COUNT(*) AS n FROM payment_attempts ${sql}`, params))?.n ?? 0
  const lignes = await query(
    `SELECT * FROM payment_attempts ${sql} ORDER BY created_at DESC, id DESC LIMIT ${pagination.limit} OFFSET ${pagination.offset}`,
    params,
  )
  return sendList(response, lignes.map(tentative), paginationMeta(pagination, Number(total)))
})

const idSchema = z.object({ id: z.coerce.number().int().positive() })

adminRouter.get('/jeko/payments/:id', validate({ params: idSchema }), async (request, response) => {
  const t = await queryOne('SELECT * FROM payment_attempts WHERE id = ? LIMIT 1', [request.params.id])
  if (!t) throw ApiError.notFound('Paiement introuvable.')
  const evenements = await query('SELECT * FROM payment_events WHERE attempt_id = ? ORDER BY created_at DESC, id DESC LIMIT 100', [t.id])
  const demande = t.booking_request_id
    ? await queryOne('SELECT id, reference, status, payment_status, awaiting_payment, desired_date, besoin, paid_at, customer_kind FROM booking_requests WHERE id = ? LIMIT 1', [t.booking_request_id])
    : null
  const autres = await query('SELECT id, method, status, created_at FROM payment_attempts WHERE request_reference = ? AND id <> ? ORDER BY id DESC LIMIT 20', [t.request_reference, t.id])
  return sendData(response, {
    ...tentative(t),
    technical: {
      jekoReference: t.jeko_reference,
      paymentRequestId: t.jeko_payment_request_id,
      transactionId: t.jeko_transaction_id,
      jekoStatus: t.jeko_status,
      errorReason: t.error_reason,
      errorHttpStatus: t.error_http_status,
      errorMessage: t.error_message,
      redirectHost: t.redirect_host,
      amountCents: t.amount === null ? null : Number(t.amount) * 100,
      mode: t.mode,
    },
    request: demande
      ? { id: demande.id, reference: demande.reference, status: demande.status, paymentStatus: demande.payment_status, awaitingPayment: Boolean(Number(demande.awaiting_payment)), besoin: demande.besoin, customerKind: demande.customer_kind, paidAt: demande.paid_at }
      : null,
    otherAttempts: autres.map((a) => ({ id: a.id, method: a.method, status: a.status, createdAt: a.created_at })),
    events: evenements.map(evenement),
    diagnostics: diagnostics(t, evenements),
    supportSummary: dossierSupport(t, evenements),
  })
})

/** Vérification chez Jèko d'UNE tentative : un appel réseau, déclenché par l'administratrice. */
adminRouter.post('/jeko/payments/:id/verify', jekoActionLimiter, validate({ params: idSchema }), async (request, response) => {
  const t = await queryOne('SELECT * FROM payment_attempts WHERE id = ? LIMIT 1', [request.params.id])
  if (!t) throw ApiError.notFound('Paiement introuvable.')
  const resultat = await verifierTentative(t)
  const apres = await queryOne('SELECT * FROM payment_attempts WHERE id = ? LIMIT 1', [t.id])
  return sendData(response, { ok: resultat.ok, message: resultat.message, changed: Boolean(resultat.change), payment: tentative(apres) })
})

/** Actualise d'un coup les paiements encore en attente (récents, avec identifiant Jèko). */
adminRouter.post('/jeko/payments/refresh', jekoActionLimiter, async (_request, response) => {
  const lignes = await query(
    `SELECT * FROM payment_attempts
      WHERE ${PAR_MODE_LIVE} AND status = 'pending' AND jeko_payment_request_id IS NOT NULL
        AND created_at >= (NOW() - INTERVAL 14 DAY)
        AND (last_checked_at IS NULL OR last_checked_at < (NOW() - INTERVAL 20 SECOND))
      ORDER BY created_at DESC LIMIT 10`,
  )
  let misAJour = 0
  let erreurs = 0
  // Par lots de 5 : les appels partent ensemble, sans dépasser la limite de débit de Jèko (500 requêtes / minute).
  for (let i = 0; i < lignes.length; i += 5) {
    const lot = await Promise.all(lignes.slice(i, i + 5).map((t) => verifierTentative(t).catch(() => ({ ok: false }))))
    for (const r of lot) {
      if (!r.ok) erreurs += 1
      else if (r.change) misAJour += 1
    }
  }
  return sendData(response, { checked: lignes.length, updated: misAJour, errors: erreurs })
})

const evenementsSchema = z.object({
  outcome: z.enum(['processed', 'duplicate', 'ignored', 'unmatched', 'rejected', 'error']).optional(),
  source: z.enum(['initiation', 'webhook', 'verification']).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
})

adminRouter.get('/jeko/events', validate({ query: evenementsSchema }), async (request, response) => {
  const q = getQuery(request)
  const pagination = readPagination({ query: q })
  const where = []
  const params = []
  if (q.outcome) { where.push('outcome = ?'); params.push(q.outcome) }
  if (q.source) { where.push('source = ?'); params.push(q.source) }
  const sql = where.length ? `WHERE ${where.join(' AND ')}` : ''
  const total = (await queryOne(`SELECT COUNT(*) AS n FROM payment_events ${sql}`, params))?.n ?? 0
  const lignes = await query(`SELECT * FROM payment_events ${sql} ORDER BY created_at DESC, id DESC LIMIT ${pagination.limit} OFFSET ${pagination.offset}`, params)
  return sendList(response, lignes.map(evenement), paginationMeta(pagination, Number(total)))
})
