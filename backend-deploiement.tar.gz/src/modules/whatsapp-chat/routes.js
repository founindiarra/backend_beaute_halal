import { Router } from 'express'
import { z } from 'zod'

import { config } from '../../config/env.js'
import { ApiError } from '../../lib/ApiError.js'
import { sendData } from '../../lib/http.js'
import { whatsappChatLimiter, whatsappChatSendLimiter } from '../../middleware/rateLimit.js'
import { getQuery, validate } from '../../middleware/validate.js'
import {
  changementsDepuis,
  curseurActuel,
  envoyerDansConversation,
  etatSynchronisation,
  listerConversations,
  marquerLue,
  messagesDe,
  ouvrirConversationAvec,
  reessayer,
  serialiserConversation,
  synchroniser,
  totalNonLus,
  trouverConversation,
} from './model.js'

/**
 * Discussions WhatsApp du dashboard. Montées sous /admin/whatsapp/chat : le droit « whatsapp » (réservé à
 * l'administratrice, jamais accordable à un agent) est vérifié par la garde de routes/index.js.
 * Le navigateur ne parle qu'à ces routes ; le service WhatsApp, son secret et ses événements restent côté serveur.
 */
export const adminRouter = Router()

adminRouter.use('/whatsapp/chat', whatsappChatLimiter, (_request, response, next) => {
  response.set('Cache-Control', 'no-store')
  if (!config.whatsapp.chat.enabled) {
    return next(new ApiError(503, 'Les discussions WhatsApp sont désactivées sur le serveur (WHATSAPP_CHAT_ENABLED).', { code: 'WHATSAPP_CHAT_DISABLED' }))
  }
  return next()
})

const id = z.coerce.number().int().positive()
const texte = z
  .string()
  .trim()
  .min(1, 'Le message est vide.')
  .max(4000, 'Message trop long (4000 caractères au plus).')
  // Pas de caractères de contrôle (sauf retour à la ligne et tabulation).
  .refine((s) => !/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/.test(s), 'Caractères non autorisés.')
const clientRef = z.string().trim().regex(/^[A-Za-z0-9_-]{8,64}$/, 'Référence d’envoi invalide.')

/** GET /conversations — plus récentes d'abord ; recherche par nom ou numéro ; filtre « non lues ». */
adminRouter.get(
  '/whatsapp/chat/conversations',
  validate({
    query: z.object({
      q: z.string().trim().max(80).optional(),
      unread: z.enum(['0', '1']).optional(),
      limit: z.coerce.number().int().min(1).max(100).optional(),
      offset: z.coerce.number().int().min(0).max(100000).optional(),
    }),
  }),
  async (request, response) => {
    const f = getQuery(request)
    await synchroniser()
    const cursor = await curseurActuel()
    const { rows, total } = await listerConversations({ q: f.q, nonLues: f.unread === '1', limit: f.limit ?? 30, offset: f.offset ?? 0 })
    return response.json({ success: true, data: rows, meta: { total, limit: f.limit ?? 30, offset: f.offset ?? 0 }, unread: await totalNonLus(), cursor, sync: etatSynchronisation() })
  },
)

/** GET /summary — total des messages non lus (pastille du menu) et état de la synchronisation. */
adminRouter.get('/whatsapp/chat/summary', async (_request, response) => {
  await synchroniser()
  return sendData(response, { unread: await totalNonLus(), sync: etatSynchronisation() })
})

/**
 * GET /updates?since=<ms> — tout ce qui a changé depuis le curseur (temps réel par synchronisation périodique).
 * Sans `since`, ne renvoie que le curseur de départ.
 */
adminRouter.get(
  '/whatsapp/chat/updates',
  validate({ query: z.object({ since: z.coerce.number().int().min(0).optional() }) }),
  async (request, response) => {
    const { since } = getQuery(request)
    const sync = await synchroniser()
    const changes = await changementsDepuis(since ?? 0)
    return sendData(response, {
      ...changes,
      unread: await totalNonLus(),
      sync: { ok: sync.ok, code: sync.code, ...etatSynchronisation() },
    })
  },
)

/** POST /sync — relecture immédiate des événements du service. */
adminRouter.post('/whatsapp/chat/sync', async (_request, response) => {
  const issue = await synchroniser({ forcer: true })
  return sendData(response, { ...issue, ...etatSynchronisation() })
})

adminRouter.get(
  '/whatsapp/chat/conversations/:id',
  validate({ params: z.object({ id }) }),
  async (request, response) => {
    const ligne = await trouverConversation(request.params.id)
    if (!ligne) throw ApiError.notFound('Conversation introuvable.')
    return sendData(response, serialiserConversation(ligne))
  },
)

/** GET /conversations/:id/messages?before=<id> — historique paginé (du plus ancien au plus récent). */
adminRouter.get(
  '/whatsapp/chat/conversations/:id/messages',
  validate({
    params: z.object({ id }),
    query: z.object({ before: z.coerce.number().int().positive().optional(), limit: z.coerce.number().int().min(1).max(100).optional() }),
  }),
  async (request, response) => {
    const ligne = await trouverConversation(request.params.id)
    if (!ligne) throw ApiError.notFound('Conversation introuvable.')
    const f = getQuery(request)
    const page = await messagesDe(ligne.id, { avant: f.before, limit: f.limit ?? 40 })
    return sendData(response, { conversation: serialiserConversation(ligne), messages: page.rows, hasMore: page.hasMore })
  },
)

adminRouter.post(
  '/whatsapp/chat/conversations/:id/read',
  validate({ params: z.object({ id }) }),
  async (request, response) => {
    const ligne = await trouverConversation(request.params.id)
    if (!ligne) throw ApiError.notFound('Conversation introuvable.')
    await marquerLue(ligne.id)
    return sendData(response, serialiserConversation(await trouverConversation(ligne.id)))
  },
)

/** POST /conversations/:id/messages — répond à une conversation. `clientRef` : l'envoi est rejouable sans doublon. */
adminRouter.post(
  '/whatsapp/chat/conversations/:id/messages',
  whatsappChatSendLimiter,
  validate({ params: z.object({ id }), body: z.object({ text: texte, clientRef: clientRef.optional() }).strict() }),
  async (request, response) => {
    const issue = await envoyerDansConversation({
      conversationId: request.params.id,
      texte: request.body.text,
      clientRef: request.body.clientRef,
      actor: request.user,
    })
    return response.status(issue.rejoue ? 200 : 201).json({ success: true, data: issue.message, replayed: issue.rejoue })
  },
)

/** POST /conversations — démarre une discussion avec un numéro (consentement vérifié) et envoie le premier message. */
adminRouter.post(
  '/whatsapp/chat/conversations',
  whatsappChatSendLimiter,
  validate({ body: z.object({ phone: z.string().trim().min(6).max(24), text: texte, clientRef: clientRef.optional() }).strict() }),
  async (request, response) => {
    const conv = await ouvrirConversationAvec(request.body.phone)
    const issue = await envoyerDansConversation({ conversationId: conv.id, texte: request.body.text, clientRef: request.body.clientRef, actor: request.user })
    return response
      .status(issue.rejoue ? 200 : 201)
      .json({ success: true, data: { conversation: serialiserConversation(await trouverConversation(conv.id)), message: issue.message }, replayed: issue.rejoue })
  },
)

/** POST /messages/:id/retry — renvoie un message en échec (une seule fois, même en cas de double clic). */
adminRouter.post(
  '/whatsapp/chat/messages/:id/retry',
  whatsappChatSendLimiter,
  validate({ params: z.object({ id }) }),
  async (request, response) => {
    const issue = await reessayer({ messageId: request.params.id, actor: request.user })
    return response.status(issue.rejoue ? 200 : 202).json({ success: true, data: issue.message, replayed: issue.rejoue })
  },
)
