import rateLimit from 'express-rate-limit'

import { config } from '../config/env.js'

const message = (text) => ({
  success: false,
  error: { code: 'TOO_MANY_REQUESTS', message: text },
})

const base = {
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  // En développement les limites sont très larges pour ne pas gêner les tests.
  skip: () => !config.isProduction && process.env.FORCE_RATE_LIMIT !== 'true',
}

/** Limite générale de l'API. */
export const generalLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 600,
  message: message('Trop de requêtes. Réessayez dans quelques minutes.'),
})

/** Création de rendez-vous : protège contre le spam de réservations. */
export const bookingLimiter = rateLimit({
  ...base,
  windowMs: 60 * 60 * 1000,
  limit: 10,
  message: message('Trop de demandes de rendez-vous. Réessayez dans une heure.'),
})

/** Formulaire de contact. */
export const contactLimiter = rateLimit({
  ...base,
  windowMs: 60 * 60 * 1000,
  limit: 8,
  message: message('Trop de messages envoyés. Réessayez dans une heure.'),
})

/** Connexion admin : freine les tentatives de force brute. */
export const loginLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  message: message('Trop de tentatives de connexion. Réessayez dans 15 minutes.'),
})

/**
 * Reconnaissance d'une cliente par son numéro, sur le site public.
 *
 * Cette route répond « connue » ou « inconnue » sur un numéro de téléphone.
 * Sans limite, on pourrait balayer les numéros d'un opérateur pour dresser
 * la liste des clientes du salon — une information qui ne regarde personne.
 * Vingt essais par quart d'heure suffisent largement à une cliente qui se
 * trompe de chiffre, et rendent le balayage inutilisable.
 */
export const lookupLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 20,
  message: message('Trop de recherches. Réessayez dans quelques minutes.'),
})

/** Page WhatsApp du dashboard : statut et QR interrogés toutes les quelques secondes pendant la connexion. */
export const whatsappLimiter = rateLimit({
  ...base,
  // Les discussions ont leurs propres limiteurs (relecture toutes les quelques secondes).
  skip: (request) => base.skip() || request.originalUrl.includes('/whatsapp/chat'),
  windowMs: 60 * 1000,
  limit: 60,
  message: message('Trop de requêtes vers WhatsApp. Patientez une minute.'),
})

/** Actions qui agissent sur le compte WhatsApp (connexion, déconnexion, message d'essai). */
export const whatsappActionLimiter = rateLimit({
  ...base,
  windowMs: 5 * 60 * 1000,
  limit: 12,
  message: message('Trop d’actions WhatsApp. Réessayez dans quelques minutes.'),
})

/** Rubrique « Paiements Jèko » du dashboard : listes et détails relus à l'écran. */
export const jekoLimiter = rateLimit({
  ...base,
  windowMs: 60 * 1000,
  limit: 90,
  message: message('Trop de requêtes vers les paiements. Patientez une minute.'),
})

/** Vérifications de statut chez Jèko (appels réseau sortants). */
export const jekoActionLimiter = rateLimit({
  ...base,
  windowMs: 60 * 1000,
  limit: 20,
  message: message('Trop de vérifications chez Jèko. Patientez une minute.'),
})

/** Discussions WhatsApp : lecture et relecture périodique du dashboard (toutes les 3 s, plusieurs onglets possibles). */
export const whatsappChatLimiter = rateLimit({
  ...base,
  windowMs: 60 * 1000,
  limit: 240,
  message: message('Trop de requêtes vers les discussions WhatsApp. Patientez un instant.'),
})

/** Envois depuis le dashboard : au plus 30 par minute, quelle que soit la cliente. */
export const whatsappChatSendLimiter = rateLimit({
  ...base,
  windowMs: 60 * 1000,
  limit: 30,
  message: message('Trop de messages envoyés. Patientez une minute.'),
})
