import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'

import { config } from './config/env.js'
import { errorHandler, notFound } from './middleware/error.js'
import { generalLimiter } from './middleware/rateLimit.js'
import routes from './routes/index.js'

export function createApp() {
  const app = express()

  // Derrière un reverse proxy (Nginx, Apache), pour obtenir la vraie IP cliente.
  app.set('trust proxy', 1)
  app.disable('x-powered-by')

  app.use(
    helmet({
      // Les images sont servies à un front hébergé sur un autre port/domaine.
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      contentSecurityPolicy: false,
    }),
  )

  app.use(
    cors({
      origin(origin, callback) {
        // Autorise les outils sans origine (curl, Postman) et les origines listées.
        if (!origin || config.corsOrigins.includes(origin)) return callback(null, true)
        return callback(new Error(`Origine non autorisée : ${origin}`))
      },
      credentials: true,
      methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
    }),
  )

  // `rawBody` : le corps exact reçu, nécessaire pour vérifier la signature du webhook de paiement (Jèko).
  app.use(
    express.json({
      limit: '1mb',
      // Le dépôt d'image en base64 a son propre analyseur (limite plus large) dans modules/uploads.
      type: (request) => !request.path.endsWith('/admin/uploads/base64') && /json/i.test(request.headers['content-type'] ?? ''),
      verify: (request, _response, buffer) => {
        request.rawBody = buffer
      },
    }),
  )
  app.use(express.urlencoded({ extended: true, limit: '1mb' }))

  if (config.env !== 'test') {
    app.use(morgan(config.isProduction ? 'combined' : 'dev'))
  }

  // Images téléversées, servies en statique avec un cache raisonnable.
  app.use(
    config.upload.publicPath,
    express.static(config.upload.dir, { maxAge: '7d', fallthrough: true, index: false }),
  )

  app.use('/api', generalLimiter, routes)

  // Racine : petit repère pour savoir que l'API tourne.
  app.get('/', (_request, response) =>
    response.json({
      name: 'Beauté Halal — API',
      documentation: '/api/health',
      environment: config.env,
    }),
  )

  app.use(notFound)
  app.use(errorHandler)

  return app
}

export default createApp
