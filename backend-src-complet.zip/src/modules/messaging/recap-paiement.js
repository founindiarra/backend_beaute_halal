/**
 * Récapitulatif envoyé à la cliente dès que ses 5 000 FCFA sont payés : e-mail ET WhatsApp, avec le même contenu.
 * Fonction PURE (aucun accès base, aucun envoi) : elle reçoit la demande (ligne `booking_requests`), le catalogue,
 * le rendez-vous éventuel et renvoie les textes. L'envoi est fait par `envoyerRecapPaiement` (notifications.js).
 */
import { libelleMethode } from '../booking-requests/methodes.js'
import { versGsm } from '../../lib/sms.js'

const JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi']
const JOURS_COURTS = ['dim', 'lun', 'mar', 'mer', 'jeu', 'ven', 'sam']
const MOIS_COURTS = ['janv', 'fevr', 'mars', 'avr', 'mai', 'juin', 'juil', 'aout', 'sept', 'oct', 'nov', 'dec']
const MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre']

const iso = (v) => (!v ? null : v instanceof Date ? `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}` : String(v).slice(0, 10))
const hhmm = (v) => (v ? String(v).slice(0, 5) : null)

/** « mardi 3 novembre 2026 » (sans toLocaleDateString : indépendant des données de langue du serveur). */
export function jourComplet(valeur) {
  const texte = iso(valeur)
  const [a, m, j] = String(texte ?? '').split('-').map(Number)
  if (!a || !m || !j) return ''
  return `${JOURS[new Date(Date.UTC(a, m - 1, j)).getUTCDay()]} ${j} ${MOIS[m - 1]} ${a}`
}

export function montant(valeur, devise = 'FCFA') {
  if (valeur === null || valeur === undefined || valeur === '' || Number.isNaN(Number(valeur))) return ''
  return `${String(Math.round(Number(valeur))).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} ${devise}`
}

const CONSULTATION_MIN = 30
export const SMS_MAX = 155

/** « mar 3 nov » — version courte pour les SMS. */
export function jourCourt(valeur) {
  const [a, m, j] = String(iso(valeur) ?? '').split('-').map(Number)
  if (!a || !m || !j) return ''
  return `${JOURS_COURTS[new Date(Date.UTC(a, m - 1, j)).getUTCDay()]} ${j} ${MOIS_COURTS[m - 1]}`
}

/**
 * Durée estimée, en très bref, pour un SMS : « une journée entière ou une journée et demie, voire 2 à 3 jours » → « 1 a 1,5 jour ».
 * Le texte vient du catalogue (modifiable dans le dashboard) : on ne garde que l'estimation principale.
 */
export function dureeBreve(texte) {
  let t = String(texte ?? '').trim().toLowerCase()
  if (!t) return ''
  t = t.split(/,\s*(?:voire|jusqu)/)[0]
  t = t.replace(/\ben moyenne\b/g, '').replace(/\benviron\s*/g, '~').replace(/\bminimum\b/g, 'min')
  t = t.replace(/\bune journée entière ou une journée et demie\b/g, '1 à 1,5 jour')
  t = t.replace(/\bune journée et demie\b/g, '1,5 jour').replace(/\bune journée entière\b/g, '1 jour').replace(/\bune journée\b/g, '1 jour')
  t = t.replace(/\bune demi-journée\b/g, '1/2 jour').replace(/\bheures?\b/g, 'h')
  t = t.replace(/(\d+(?:,\d+)?)\s*h\s*à\s*(\d+(?:,\d+)?)\s*h/g, '$1 à $2 h').replace(/\s+/g, ' ').trim()
  return versGsm(t.replace(/ à /g, ' a ')).replace(/\s*,\s*$/, '')
}

/**
 * @param {object} p
 * @param {object} p.ligne       ligne booking_requests (snake_case)
 * @param {object} p.catalogue   catalogue des tarifs (types, volumes, formules, site, whatsapp)
 * @param {object|null} p.rendezVous  rendez-vous créé (facultatif)
 * @param {boolean} p.confirme   le rendez-vous a-t-il été confirmé ?
 * @param {object|null} p.creneau  { date, time } du rendez-vous confirmé
 * @param {string} p.adresse     adresse du salon (facultative)
 * @returns {{ subject: string, email: string, whatsapp: string, sms: string, sections: object[] }}
 */
export function construireRecapPaiement({ ligne, catalogue = {}, rendezVous = null, confirme = false, creneau = null, adresse = '' }) {
  const salon = 'Beauté Halal'
  const type = (catalogue.lockTypes ?? []).find((t) => t.id === ligne.lock_type) ?? null
  const volume = (catalogue.volumes ?? []).find((v) => v.id === ligne.volume) ?? null
  const formule = (catalogue.formules ?? []).find((f) => f.id === ligne.formule) ?? null
  const methodes = catalogue.site?.methodes?.[ligne.lock_type]?.methodes ?? []
  const methodeId = ligne.methode || null
  const methodeLibelle = methodeId ? libelleMethode(ligne.lock_type, methodeId) : null
  const methodeDuree = methodes.find((m) => m.id === methodeId)?.duree || null
  const noteTemps = catalogue.site?.methodes?.[ligne.lock_type]?.noteTemps ?? null
  const whatsapp = String(catalogue.whatsapp?.display ?? '').trim()
  const etatLibelle = ligne.etat ? (type?.etats ?? []).find((e) => e.id === ligne.etat)?.label ?? null : null
  const delaiLibelle = ligne.delai ? (type?.delais ?? []).find((d) => d.id === ligne.delai)?.label ?? null : null

  const consultation = ['sur_place', 'telephone', 'whatsapp'].includes(ligne.consultation_mode)
  const avecPrestation = consultation && Boolean(ligne.service_date)
  const prestationPrevue = !consultation || avecPrestation
  const paye = Number(ligne.payment_amount ?? 0) || 0
  const nouvelle = ligne.customer_kind !== 'ancienne'
  const joursConsultation = jourComplet(ligne.consultation_date ?? ligne.desired_date)
  const jourChoisi = jourComplet(creneau?.date ?? (consultation ? ligne.consultation_date : ligne.desired_date) ?? ligne.desired_date)
  const heureChoisie = hhmm(creneau?.time) ?? hhmm(consultation ? ligne.consultation_time : ligne.desired_time)
  const prenom = String(ligne.first_name ?? '').trim()

  const sections = []

  // 1. Le rendez-vous
  const rdv = []
  rdv.push(`Statut : ${confirme && jourChoisi ? 'confirmé ✔' : 'demande enregistrée (le salon confirme le jour et l’heure très vite)'}`)
  if (jourChoisi) rdv.push(`Date : ${jourChoisi}`)
  if (heureChoisie) rdv.push(`Heure : ${heureChoisie}`)
  if (!jourChoisi) rdv.push('Date et heure : le salon vous contacte pour les fixer')
  if (adresse) rdv.push(`Lieu : ${adresse}`)
  rdv.push(`Référence : ${ligne.reference}`)
  sections.push({ titre: 'Votre rendez-vous', icone: '📅', lignes: rdv })

  // 2. Le paiement
  if (paye) {
    sections.push({
      titre: 'Votre paiement',
      icone: '💳',
      lignes: [
        `Montant reçu : ${montant(paye)}`,
        consultation
          ? 'Il correspond aux frais de votre consultation capillaire.'
          : nouvelle
            ? 'Cette avance couvre vos frais de consultation (nouvelle cliente).'
            : 'Cette avance est déduite du prix de votre prestation (ancienne cliente).',
      ],
    })
  }

  // 3. La consultation
  if (consultation) {
    const l = ['Prestation : Consultation capillaire', `Durée : ${CONSULTATION_MIN} minutes`]
    if (joursConsultation) l.push(`Jour : ${joursConsultation}${hhmm(ligne.consultation_time) ? ` à ${hhmm(ligne.consultation_time)}` : ''}`)
    l.push('Au programme : analyse technique de vos cheveux et de votre cuir chevelu, conseils personnalisés et tarif précis.')
    sections.push({ titre: 'Votre consultation', icone: '🗓', lignes: l })
  }

  // 4. La coiffure souhaitée
  const coiffure = []
  if (prestationPrevue) {
    if (ligne.besoin === 'creation') coiffure.push('Prestation : Installation de locks')
    else coiffure.push(`Prestation : ${formule?.label ?? 'Resserrage'}`)
    if (type) coiffure.push(`Type de locks : ${type.name}${type.size ? ` (${type.size})` : ''}`)
    if (ligne.besoin === 'creation') coiffure.push(`Méthode de pose : ${methodeLibelle ?? 'à conseiller par le salon'}`)
    if (delaiLibelle) coiffure.push(`Dernière séance : ${delaiLibelle}`)
    if (etatLibelle) coiffure.push(`État actuel des locks : ${etatLibelle}`)
    if (volume) coiffure.push(`Volume de cheveux : ${volume.label}`)
    if (ligne.longueur) coiffure.push(`Longueur : ${ligne.longueur}`)
  }
  if (ligne.inspiration_title) coiffure.push(`Modèle choisi : « ${ligne.inspiration_title} »`)
  if (avecPrestation) coiffure.push(`Prestation souhaitée le : ${jourComplet(ligne.service_date)}${hhmm(ligne.service_time) ? ` à ${hhmm(ligne.service_time)}` : ' (heure à confirmer avec le salon)'}`)
  if (coiffure.length) sections.push({ titre: 'Votre coiffure', icone: '💇🏾‍♀️', lignes: coiffure })

  // 5. Durée et tarif
  const prix = []
  if (prestationPrevue) {
    if (methodeDuree) prix.push(`Durée estimée de la pose : ${methodeDuree}`)
    else if (noteTemps) prix.push(`Durée estimée : ${noteTemps}`)
  }
  if (Number(ligne.estimate_total) > 0) prix.push(`Tarif indicatif : ${Number(ligne.estimate_partial) ? 'à partir de ' : ''}${montant(ligne.estimate_total)}`)
  prix.push(consultation || ligne.besoin === 'creation'
    ? 'Le tarif précis est fixé par le salon, en consultation ou à distance sur photo / vidéo, puis réglé sur place.'
    : 'Le tarif final est confirmé par le salon.')
  sections.push({ titre: 'Durée et tarif', icone: '⏱', lignes: prix })

  // 6. Bon à savoir (réglé dans le dashboard)
  const politique = catalogue.site?.politique?.sections ?? []
  const garde = politique.filter((x) => /annulation|retard|horaire/i.test(x.titre ?? ''))
  if (garde.length) sections.push({ titre: 'Bon à savoir', icone: 'ℹ️', lignes: garde.map((x) => `${x.titre} : ${x.texte}`) })
  const devis = politique.find((x) => /prix/i.test(x.titre ?? ''))

  // 7. Contact
  const contact = []
  if (whatsapp) contact.push(`Une question, une photo ou une vidéo à nous envoyer pour votre devis ? Écrivez-nous sur WhatsApp au ${whatsapp}.`)
  if (devis && whatsapp && !consultation) contact.push(`${devis.texte}`)
  if (contact.length) sections.push({ titre: 'Nous contacter', icone: '💬', lignes: contact })

  const subject = confirme
    ? `Votre rendez-vous est confirmé — ${salon} (${ligne.reference})`
    : `Paiement reçu — votre demande ${ligne.reference} — ${salon}`

  // Phrases d'introduction et de conclusion (un message qui se lit, pas une liste brute).
  const accueil = `Bonjour ${prenom},`.replace(/,$/, prenom ? ',' : '')
  const remerciement = paye
    ? `Merci pour votre confiance et pour votre paiement de ${montant(paye)}, bien reçu.`
    : 'Merci pour votre confiance : votre demande est bien reçue.'
  const suite = confirme && jourChoisi
    ? `Votre rendez-vous est confirmé pour le ${jourChoisi}${heureChoisie ? ` à ${heureChoisie}` : ''}. Voici le récapitulatif complet, à conserver.`
    : 'Votre demande est bien enregistrée : le salon vous confirme le jour et l’heure très vite. Voici le récapitulatif complet de votre réservation.'
  const conclusion = 'Nous avons hâte de vous accueillir et de prendre soin de vos cheveux.'

  const trait = '────────────────────'
  const email = [
    accueil, '', remerciement, suite, '',
    ...sections.flatMap((x) => [trait, x.titre.toUpperCase(), ...x.lignes, '']),
    trait, '', conclusion, 'À très bientôt,', `L’équipe ${salon}`,
  ].join('\n')

  const wa = [
    `*${salon}* 🤍`, '', accueil, '', `${remerciement} ${suite}`, '',
    ...sections.flatMap((x) => [`${x.icone} *${x.titre}*`, ...x.lignes.map((l) => (/^[^:]{2,40} : /.test(l) ? `▫️ ${l.replace(/^([^:]{2,40}) : /, '_$1_ : ')}` : l)), '']),
    conclusion, 'À très bientôt ! 🤍', `_${salon}_`,
  ].join('\n')

  // SMS : 155 caractères MAXIMUM (espaces compris, sans accents). On ajoute les éléments par ordre d'importance tant que ça tient.
  const court = (t, n) => (t.length > n ? `${t.slice(0, n - 1).trimEnd()}.` : t)
  const quand = jourChoisi ? `${jourCourt(creneau?.date ?? (consultation ? ligne.consultation_date : ligne.desired_date) ?? ligne.desired_date)}${heureChoisie ? ` a ${heureChoisie}` : ''}` : ''
  const tete = confirme && quand ? `Beaute Halal: RDV CONFIRME ${quand}.` : quand ? `Beaute Halal: demande recue pour ${quand}.` : 'Beaute Halal: demande recue, nous vous appelons.'
  const quoi = []
  if (consultation) quoi.push('Consultation')
  if (prestationPrevue) {
    if (type) quoi.push(versGsm(type.name))
    else quoi.push(ligne.besoin === 'creation' ? 'Installation locks' : versGsm(formule?.label ?? 'Resserrage'))
  }
  const duree = consultation && !avecPrestation ? `${CONSULTATION_MIN} min` : dureeBreve(methodeDuree || '')
  // [texte, priorité] : plus la priorité est basse, plus l'élément est sacrifié en dernier. L'ordre du tableau = ordre de lecture.
  const elements = [
    [quoi.length ? `${quoi.join(' + ')}.` : '', 2],
    [duree ? `Duree ~${duree.replace(/^~\s*/, '')}.` : '', 3],
    [ligne.inspiration_title ? `Modele: ${court(versGsm(ligne.inspiration_title), 24)}.` : '', 5],
    [paye ? `Paye ${montant(paye, 'F')}.` : '', 4],
    [`Ref ${ligne.reference}.`, 1],
  ].filter(([t]) => t)
  const gardes = new Set()
  let longueur = tete.length
  for (const [texte, rang] of [...elements].sort((a, b) => a[1] - b[1])) {
    if (longueur + 1 + texte.length <= SMS_MAX) { gardes.add(texte); longueur += 1 + texte.length }
  }
  const smsTexte = [tete, ...elements.map(([t]) => t).filter((t) => gardes.has(t))].join(' ')
  const sms = smsTexte.length <= SMS_MAX ? smsTexte : smsTexte.slice(0, SMS_MAX)

  return { subject, email, whatsapp: wa, sms, sections }
}
